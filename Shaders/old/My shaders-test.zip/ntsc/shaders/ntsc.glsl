#version 130

#if defined(VERTEX)
in vec4 VertexCoord;
in vec2 TexCoord;
out vec2 vTexCoord;
uniform mat4 MVPMatrix;
void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

in vec2 vTexCoord;
out vec4 FragColor;

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;

// =========================================================
// 1. إعدادات الـ Rainbow و RGB
// =========================================================
#pragma parameter PHASE_MODE "Phase Mode: 0:Manual, 1:2-Phase, 2:3-Phase" 0.0 0.0 2.0 1.0
#pragma parameter rb_power "Rainbow Strength" 0.1 0.0 2.0 0.01
#pragma parameter rb_size "Rainbow Width/Scale" 4.5 0.5 10.0 0.1
#pragma parameter rb_slant "Rainbow Tilt/Rotation" 0.0 -2.0 2.0 0.05
#pragma parameter rb_detect "Rainbow Edge Detect" 0.31 0.0 1.0 0.01
#pragma parameter rb_speed "Rainbow Cycle Speed" 0.1 0.0 1.0 0.01
#pragma parameter rb_phase "Rainbow Phase Shift" 0.0 0.0 6.28 0.1
#pragma parameter rb_sat "Rainbow Saturation" 1.0 0.0 2.0 0.05
#pragma parameter rb_blend "Rainbow Mix Mode" 0.5 0.0 1.0 0.05

// =========================================================
// 2. إعدادات سيلان اللون والظلال (GTU/Bleed)
// =========================================================
#pragma parameter ghosting "Signal Ghosting (Ringing)" 0.4 0.0 1.0 0.05
#pragma parameter COL_BLEED "Chroma Spread (Bleed)" 3.0 0.0 20.0 0.1
#pragma parameter bleed_dir "Bleed Direction (L <-> R)" 0.0 -1.0 1.0 0.1
#pragma parameter black_bleed "Black Level Smear" 0.2 0.0 5.0 0.05
#pragma parameter glow_str "Signal Halo Glow" 0.15 0.0 5.0 0.05
#pragma parameter fringe_str "Edge Color Fringing" 0.4 0.0 2.0 0.1

// =========================================================
// 3. إعدادات الـ Mega Drive والضوضاء والاهتزاز
// =========================================================
#pragma parameter de_dither "MD De-Dither Intensity" 1.0 0.0 2.0 0.1
#pragma parameter jail_str "MD Vertical Jailbars" 0.15 0.0 0.5 0.01
#pragma parameter jail_width "MD Jailbar Spacing" 1.5 0.5 5.0 0.1
#pragma parameter NOISE_STR "Analog Signal Noise" 0.04 0.0 2.0 0.01
#pragma parameter JITTER "Signal Jitter (Shake)" 0.04 0.0 3.0 0.05

// =========================================================
// 4. إعدادات الصورة النهائية والـ CRT
// =========================================================
#pragma parameter MD_WARM "Analog Warmth" 0.05 -0.2 0.2 0.01
#pragma parameter MD_SHARP "Luma Sharpness" 0.1 0.0 2.0 0.05
#pragma parameter ntsc_hue "NTSC Tint (Hue)" 0.0 -3.14 3.14 0.05
//#pragma parameter tv_mist "Signal Blur (Mist)" 0.4 0.0 5.0 0.05

uniform float PHASE_MODE, rb_power, rb_size, rb_slant, rb_detect, rb_speed, rb_phase, rb_sat, rb_blend;
uniform float ghosting, COL_BLEED, bleed_dir, black_bleed, glow_str, fringe_str;
uniform float de_dither, jail_str, jail_width;
uniform float MD_WARM, MD_SHARP, ntsc_hue, tv_mist;
uniform float NOISE_STR, JITTER;

const mat3 RGBtoYIQ = mat3(0.2989, 0.5870, 0.1140, 0.5959, -0.2744, -0.3216, 0.2115, -0.5229, 0.3114);
const mat3 YIQtoRGB = mat3(1.0, 0.956, 0.6210, 1.0, -0.2720, -0.6474, 1.0, -1.1060, 1.7046);

float rand(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 1.0 / TextureSize.y);
    float time = float(FrameCount);

    // تطبيق الـ JITTER
    vec2 uv = vTexCoord;
    uv.x += (rand(vec2(time, uv.y)) - 0.5) * JITTER * ps.x;

    // 1. Ghosting & Ringing
    vec3 main_c = texture(Texture, uv).rgb;
    vec3 g_l = texture(Texture, uv - vec2(ps.x * 2.0, 0.0)).rgb;
    vec3 g_r = texture(Texture, uv + vec2(ps.x * 2.0, 0.0)).rgb;
    vec3 col = mix(main_c, mix(g_l, g_r, 0.5 + bleed_dir * 0.5), ghosting * 0.4);

    // 2. De-Dither & Jailbars
    vec3 cL = texture(Texture, uv - vec2(ps.x * de_dither, 0.0)).rgb;
    vec3 cR = texture(Texture, uv + vec2(ps.x * de_dither, 0.0)).rgb;
    col = mix(col, (cL + cR) * 0.5, 0.4);
    float jail = sin(uv.x * TextureSize.x * jail_width) * jail_str;

    // 3. Signal Analysis (YIQ)
    vec3 yiq = col * RGBtoYIQ;
    float lumaL = (cL * RGBtoYIQ).r;
    float lumaR = (cR * RGBtoYIQ).r;

    // 4. Advanced RGB Rainbow (مع ميزة الـ Phase Modes)
    float p_slant = rb_slant;
    float p_speed = rb_speed;

    if (PHASE_MODE == 1.0) { p_slant = 0.0; p_speed = 0.5; } // 2-Phase (Static look)
    else if (PHASE_MODE == 2.0) { p_slant = 1.0; p_speed = 0.33; } // 3-Phase (Rainbow Crawl)

    float edge = abs(yiq.r - lumaL) + abs(yiq.r - lumaR);
    float rb_mask = smoothstep(rb_detect, rb_detect + 0.1, edge);
    float ang = (uv.x * TextureSize.x / rb_size) + (uv.y * TextureSize.y * p_slant) + (time * p_speed) + rb_phase;
    vec2 rb_vec = vec2(sin(ang), cos(ang)) * rb_power * rb_mask * rb_sat;
    
    // 5. Chroma Bleed & Fringing
    float b_off = ps.x * COL_BLEED;
    vec2 chrL = (texture(Texture, uv - vec2(b_off, 0.0)).rgb * RGBtoYIQ).gb;
    vec2 chrR = (texture(Texture, uv + vec2(b_off, 0.0)).rgb * RGBtoYIQ).gb;
    vec2 chroma = mix(yiq.gb, (chrL + chrR) * 0.5, 0.6);

    // 6. Luma Post-Processing + Noise
    float y = yiq.r;
    y += (yiq.r - lumaL) * MD_SHARP; 
    y -= (black_bleed * step(y, 0.15) * 0.05); 
    y += jail * 0.05;
    y += (rand(uv + time * 0.01) - 0.5) * NOISE_STR;

    // 7. Final Assembly & Hue Fix
    float fI = chroma.x + rb_vec.x + (yiq.r - lumaR) * fringe_str * 0.1;
    float fQ = chroma.y + rb_vec.y;
    
    float cA = cos(ntsc_hue); float sA = sin(ntsc_hue);
    vec3 final_yiq = vec3(y, fI * cA - fQ * sA, fI * sA + fQ * cA);
    vec3 final_rgb = final_yiq * YIQtoRGB;

    // 8. Color Grade & Warmth
    final_rgb.r += MD_WARM;

    FragColor = vec4(final_rgb, 1.0);
}
#endif