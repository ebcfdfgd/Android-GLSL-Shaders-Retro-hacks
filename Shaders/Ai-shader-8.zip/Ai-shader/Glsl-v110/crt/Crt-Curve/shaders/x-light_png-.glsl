/* 777-LITE-TURBO-V4-FIXED-LOTTES-MASK-BLOOM
    - FIXED: Scanlines locked perfectly.
    - ADDED: No-Taps Bloom (Zero cost).
*/

#pragma parameter BARREL_DISTORTION "Toshiba Curve (0=OFF)" 0.12 0.0 0.5 0.01
#pragma parameter BRIGHT_BOOST "Brightness Boost" 1.2 1.0 2.5 0.05
#pragma parameter BLOOM_STR "Bloom Intensity (0=OFF)" 0.3 0.0 1.0 0.05
#pragma parameter v_amount "Vignette Intensity (0=OFF)" 0.25 0.0 2.5 0.01
#pragma parameter MASK_STR "Mask Intensity (0=OFF)" 1.0 0.0 1.0 0.05
#pragma parameter MASK_W "Mask Width" 3.0 1.0 15.0 1.0
#pragma parameter MASK_H "Mask Height" 3.0 1.0 15.0 1.0
#pragma parameter SCAN_STR "Scanline Intensity (0=OFF)" 0.40 0.0 1.0 0.05
#pragma parameter hardScan "Lottes Scan Hardness" -8.0 -20.0 0.0 1.0

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 TEX0, screen_scale;
uniform mat4 MVPMatrix;
uniform vec2 TextureSize, InputSize;

void main() {
    TEX0 = TexCoord;
    screen_scale = TextureSize / InputSize;
    gl_Position = MVPMatrix * VertexCoord;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

varying vec2 TEX0, screen_scale;
uniform sampler2D Texture, SamplerMask1;
uniform vec2 TextureSize, InputSize;

#ifdef PARAMETER_UNIFORM
uniform float BARREL_DISTORTION, BRIGHT_BOOST, BLOOM_STR, v_amount, MASK_STR, MASK_W, MASK_H, SCAN_STR, hardScan;
#endif

void main() {
    // 1. Centered Coordinates
    vec2 uv = (TEX0 * screen_scale) - 0.5;
    float r2 = dot(uv, uv);

    // 2. Curvature Math
    vec2 d_uv = uv * (1.0 + r2 * vec2(BARREL_DISTORTION * 0.2, BARREL_DISTORTION * 0.8)) * (1.0 - 0.12 * BARREL_DISTORTION);

    // 3. Branchless Bounds Check
    vec2 bounds = step(abs(d_uv), vec2(0.5));
    float check = bounds.x * bounds.y;

    // 4. Hardware Sampling & Bloom (No-Taps)
    vec2 tex_uv = (d_uv + 0.5);
    vec3 res = texture2D(Texture, tex_uv / screen_scale).rgb;

    // BLOOM LOGIC: نأخذ سطوع البكسل الحالي ونضيفه فوقه
    float lum = dot(res, vec3(0.299, 0.587, 0.114));
    res += (res * lum) * BLOOM_STR;

    // 5. PIXEL-LOCKED SCANLINES
    float dst = fract((tex_uv.y * InputSize.y) - 0.5) - 0.5;
    float scanline = exp2(hardScan * dst * dst);
    res = mix(res, res * scanline, SCAN_STR);

    // 6. Universal Mask Logic
    float mw = floor(max(MASK_W, 1.0));
    float mh = floor(max(MASK_H, 1.0));
    vec3 mcol = texture2D(SamplerMask1, gl_FragCoord.xy / vec2(mw, mh)).rgb * 1.5;
    res = mix(res, res * mcol, MASK_STR);

    // 7. Final Polish
    res *= BRIGHT_BOOST;
    res *= (1.0 - r2 * v_amount);
    
    gl_FragColor = vec4(res * check, 1.0);
}
#endif