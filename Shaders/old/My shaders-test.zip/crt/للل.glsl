#version 130
/* PRINCE-CRT-ULTIMATE-WHITE-PENETRATION
    - Fixed Mask & Scanlines via gl_FragCoord
    - Integrated Vignette 013 & Corner Chromatic
    - Mask Scaling & Slot TV Matrix
    - NEW: Dynamic Glow (Linear Light Spread)
    - NEW: Black Level Restoration (Pro Contrast)
    - NEW: Phosphor Bleed (Subpixel Blending)
    - UPDATED: Guest.r Exponential Scanline Equation
*/

#pragma parameter BARREL_DISTORTION "CRT Curve Amount" 0.12 0.0 0.5 0.01
#pragma parameter ZOOM "Zoom Amount" 1.0 0.5 2.0 0.01
#pragma parameter BRIGHT_BOOST "Brightness Boost" 1.4 1.0 5.0 0.05

// --- نظام التوهج (Glow) والعدسة ---
#pragma parameter GLOW_STR "CRT Glow Strength" 0.15 0.0 0.50 0.01
#pragma parameter PHOSPHOR_BLEED "Phosphor Bleed" 0.10 0.0 0.50 0.02
#pragma parameter BLACK_LVL "Black Level Royal" 0.05 0.0 0.30 0.01
#pragma parameter CHROMA_STR "Corner Chromatic" 0.015 0.0 0.1 0.005

// --- Vignette 013 ---
#pragma parameter v_softness "Vignette Softness" 0.10 0.0 0.30 0.01
#pragma parameter v_amount "Vignette Strength" 0.5 0.0 1.0 0.05

// --- نظام السكان لاين القوي (Guest.r Logic) ---
#pragma parameter SCAN_STR "Scanline Intensity" 0.80 0.0 1.0 0.05
#pragma parameter BEAM_MIN "Beam Width (Dark)" 1.70 0.5 3.0 0.05
#pragma parameter BEAM_MAX "Beam Width (Bright)" 2.10 0.5 3.0 0.05
#pragma parameter SCAN_SHARP "Vertical Sharpness" 8.0 1.0 12.0 1.0

// --- الماسكات ---
#pragma parameter MASK_TYPE "Mask: 0.Sony|1.Slot|2.Side|3.Delta|4.Grid|5.Slot TV" 5.0 0.0 5.0 1.0
#pragma parameter MASK_SIZE "Mask Zoom (Size)" 1.0 0.5 2.0 0.1
#pragma parameter MASK_STR "Mask Strength" 0.65 0.0 1.0 0.05
#pragma parameter MASK_DYN "Dynamic Mask (Auto)" 0.35 0.0 1.0 0.05
#pragma parameter MASK_GAP "Mask RGB Gap" 0.6 0.0 2.0 0.05
#pragma parameter SUB_SHARP "Subpixel Sharpness" 3.0 1.0 5.0 0.5

// --- إعدادات الماسكات ---
#pragma parameter SONY_W "Sony Width" 3.0 1.0 6.0 1.0
#pragma parameter SLOT_W "Slot Width" 4.0 1.0 8.0 1.0
#pragma parameter SLOT_H "Slot Height" 6.0 1.0 12.0 1.0
#pragma parameter SIDE_W "Side Width" 6.0 1.0 12.0 1.0
#pragma parameter SIDE_H "Side Height" 4.0 1.0 12.0 1.0
#pragma parameter DELTA_S "Delta Mask Size" 4.0 1.0 12.0 1.0
#pragma parameter GRID_S "Grid Mask Size" 2.0 1.0 12.0 1.0
#pragma parameter CUST_W "Slot TV Width" 6.0 1.0 12.0 1.0
#pragma parameter CUST_H "Slot TV Height" 4.0 1.0 12.0 1.0

#if defined(VERTEX)
in vec4 VertexCoord, TexCoord;
out vec2 vTexCoord;
uniform mat4 MVPMatrix;
void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
}

#elif defined(FRAGMENT)
precision highp float;
in vec2 vTexCoord;
out vec4 FragColor;
uniform sampler2D Texture;
uniform vec2 TextureSize, InputSize, OutputSize;

#ifdef PARAMETER_UNIFORM
uniform float BARREL_DISTORTION, ZOOM, BRIGHT_BOOST, v_softness, v_amount, CHROMA_STR, GLOW_STR, BLACK_LVL, PHOSPHOR_BLEED;
uniform float SCAN_STR, BEAM_MIN, BEAM_MAX, SCAN_SHARP;
uniform float MASK_TYPE, MASK_SIZE, MASK_STR, MASK_DYN, MASK_GAP, SUB_SHARP;
uniform float SONY_W, SLOT_W, SLOT_H, SIDE_W, SIDE_H, DELTA_S, GRID_S, CUST_W, CUST_H;
#endif

// دالة وزن السكان لاين الأسية من Guest.r
float sw(float x, float luma) {
    float b = mix(BEAM_MIN, BEAM_MAX, luma);
    return exp2(-SCAN_SHARP * pow(x, b));
}

void main() {
    vec2 sc = TextureSize / InputSize;
    vec2 uv = (vTexCoord * sc) - 0.5;
    uv /= ZOOM;
    
    float r_sq = dot(uv, uv);
    vec2 d_uv = uv + (uv * (BARREL_DISTORTION * r_sq));
    d_uv *= (1.0 - (0.18 * BARREL_DISTORTION));
    
    float chroma = r_sq * CHROMA_STR;
    vec2 fetch_uv = (d_uv + 0.5) / sc;
    vec2 fetch_uv_r = (d_uv * (1.0 + chroma) + 0.5) / sc;
    vec2 fetch_uv_b = (d_uv * (1.0 - chroma) + 0.5) / sc;

    float ed = smoothstep(0.5, 0.498, abs(d_uv.x)) * smoothstep(0.5, 0.498, abs(d_uv.y));
    if (ed <= 0.0) { FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }

    vec3 col;
    col.r = texture(Texture, fetch_uv_r).r;
    col.g = texture(Texture, fetch_uv).g;
    col.b = texture(Texture, fetch_uv_b).b;

    vec3 glow_col = col * col * GLOW_STR; 
    
    float luma = dot(col, vec3(0.299, 0.587, 0.114));
    col *= BRIGHT_BOOST;

    float fade_x = smoothstep(0.5, 0.5 - v_softness, abs(d_uv.x));
    float fade_y = smoothstep(0.5, 0.5 - v_softness, abs(d_uv.y));
    col *= mix(1.0, fade_x * fade_y, v_amount);

    vec2 frag = gl_FragCoord.xy;
    
    // حساب السكان لاين بمعادلة Guest.r المتطورة
    float fp_y = fract(vTexCoord.y * TextureSize.y);
    float scan_weight = sw(fp_y, luma) + sw(1.0 - fp_y, luma);
    col *= mix(1.0, scan_weight, SCAN_STR);

    vec2 m_frag = frag / MASK_SIZE;
    float x_pos, vert_brick = 1.0;
    vec3 w = vec3(1.0);
    bool is_custom = false;

    if (MASK_TYPE < 0.5) { x_pos = (m_frag.x * 6.28318) / SONY_W; } 
    else if (MASK_TYPE < 1.5) { 
        x_pos = (m_frag.x * 6.28318) / SLOT_W;
        x_pos += step(0.5, fract(m_frag.y / (SLOT_H * 2.0))) * 3.1415;
        vert_brick = 0.5 + 0.5 * cos(m_frag.y * (6.28318 / SLOT_H));
    } 
    else if (MASK_TYPE < 2.5) { 
        x_pos = (m_frag.x * 6.28318) / SIDE_W;
        x_pos += step(0.5, fract(m_frag.y / (SIDE_H * 2.0))) * 3.1415;
        vert_brick = 0.7 + 0.3 * cos(m_frag.y * (6.28318 / SIDE_H));
    }
    else if (MASK_TYPE < 3.5) {
        x_pos = (m_frag.x * 6.28318) / DELTA_S;
        x_pos += step(0.5, fract(m_frag.y / (DELTA_S * 1.5))) * 2.0944;
        vert_brick = 0.6 + 0.4 * cos(m_frag.y * (6.28318 / DELTA_S));
    }
    else if (MASK_TYPE < 4.5) {
        vec2 grid = floor(m_frag / GRID_S);
        x_pos = (grid.x + grid.y) * 3.1415;
    }
    else {
        is_custom = true;
        int px = int(mod(m_frag.x * (6.0 / CUST_W), 6.0));
        int py = int(mod(m_frag.y * (4.0 / CUST_H), 4.0));
        vec3 target_w = vec3(0.0);
        if (py == 0 || py == 2) { 
            if (px == 0 || px == 3) target_w = vec3(1.0, 0.0, 0.0);
            else if (px == 1 || px == 4) target_w = vec3(0.0, 1.0, 0.0);
            else target_w = vec3(0.0, 0.0, 1.0);
        } else if (py == 1) { 
            if (px >= 3) {
                if (px == 3) target_w = vec3(1.0, 0.0, 0.0);
                else if (px == 4) target_w = vec3(0.0, 1.0, 0.0);
                else target_w = vec3(0.0, 0.0, 1.0);
            }
        } else { 
            if (px < 3) {
                if (px == 0) target_w = vec3(1.0, 0.0, 0.0);
                else if (px == 1) target_w = vec3(0.0, 1.0, 0.0);
                else target_w = vec3(0.0, 0.0, 1.0);
            }
        }
        w = clamp((target_w - MASK_GAP) * 2.0, 0.0, 1.0);
    }

    if (!is_custom) {
        w.r = 0.5 + 0.5 * cos(x_pos);                    
        w.g = 0.5 + 0.5 * cos(x_pos - 2.0944); 
        w.b = 0.5 + 0.5 * cos(x_pos - 4.1888); 
        w = clamp((w - MASK_GAP) * 2.5, 0.0, 1.0);
        w = pow(w, vec3(SUB_SHARP));
    }
    
    w = mix(w, vec3(dot(w, vec3(0.333))), PHOSPHOR_BLEED);

    float dynamic_mask = MASK_STR * (1.0 - (luma * MASK_DYN));
    col *= mix(vec3(1.0), w * 1.8 * vert_brick, dynamic_mask);

    col += glow_col; 
    col -= BLACK_LVL; 

    FragColor = vec4(clamp(col * ed, 0.0, 1.0), 1.0);
}
#endif