#version 130

#if defined(VERTEX)
in vec4 VertexCoord;
in vec2 TexCoord;
out vec2 vTexCoord;
uniform mat4 MVPMatrix;
void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

in vec2 vTexCoord;
out vec4 FragColor;

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;

// =========================================================
// 1. إعدادات الألوان (GBA/GBC/GG Color Correction)
// =========================================================
#pragma parameter COLOR_MODE "Color Mode: 0:Raw, 1:GBA, 2:GBC, 3:GameGear" 1.0 0.0 3.0 1.0
#pragma parameter CONTRAST "Contrast Strength" 1.1 0.5 2.0 0.05
#pragma parameter BRIGHTNESS "Brightness Boost" 1.05 0.5 2.0 0.05
#pragma parameter SATURATION "Saturation Strength" 1.15 0.0 2.0 0.05
#pragma parameter GBA_GAMMA "Target Gamma" 2.2 1.0 3.5 0.1

// =========================================================
// 2. إعدادات النعومة والحركة (Ghosting & Softening)
// =========================================================
#pragma parameter GHOST_STR "LCD Ghosting (Motion Blur)" 0.4 0.0 1.0 0.05
#pragma parameter GHOST_SAMPLES "Ghosting Samples" 4.0 2.0 8.0 1.0
#pragma parameter EDGE_SOFT "Edge Softening" 0.35 0.0 1.0 0.05

uniform float COLOR_MODE, CONTRAST, BRIGHTNESS, SATURATION, GBA_GAMMA;
uniform float GHOST_STR, GHOST_SAMPLES, EDGE_SOFT;

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 1.0 / TextureSize.y);
    vec2 uv = vTexCoord;

    // [1] LCD Ghosting / Motion Blur (تأثير ضبابية الحركة)
    vec3 col = texture(Texture, uv).rgb;
    if (GHOST_STR > 0.0) {
        vec3 ghost = vec3(0.0);
        // قراءة الفريمات السابقة بشكل تقريبي لخلق الخيال
        for (float i = 1.0; i <= GHOST_SAMPLES; i++) {
            ghost += texture(Texture, uv - ps * i * 0.5).rgb;
        }
        ghost /= GHOST_SAMPLES;
        col = mix(col, ghost, GHOST_STR * 0.5); // دمج الخيال مع الصورة الأصلية
    }

    // [2] Color Correction (تصحيح الألوان المتقدم لشاشات GBA/GBC/GG)
    if (COLOR_MODE >= 1.0) {
        // مصفوفة تصحيح الألوان القياسية لشاشات GBA القديمة
        const mat3 GBA_Mat = mat3(
            0.82, 0.18, 0.00,  // Red channel correction
            0.08, 0.85, 0.07,  // Green channel correction
            0.05, 0.15, 0.80   // Blue channel correction
        );
        
        // مصفوفة تصحيح الألوان لشاشات GBC
        const mat3 GBC_Mat = mat3(
            0.90, 0.10, 0.00,
            0.15, 0.80, 0.05,
            0.00, 0.10, 0.90
        );

        // مصفوفة تصحيح الألوان لشاشات Game Gear
        const mat3 GG_Mat = mat3(
            0.85, 0.10, 0.05,
            0.10, 0.80, 0.10,
            0.05, 0.10, 0.85
        );

        // تطبيق المصفوفة بناءً على الوضع المختار
        if (COLOR_MODE == 1.0)      col *= GBA_Mat;
        else if (COLOR_MODE == 2.0) col *= GBC_Mat;
        else if (COLOR_MODE == 3.0) col *= GG_Mat;

        // تعديل السطوع والتباين
        col = ((col - 0.5) * CONTRAST) + 0.5;
        col *= BRIGHTNESS;

        // تعديل التشبع
        float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
        col = mix(vec3(luma), col, SATURATION);

        // تصحيح الجاما النهائية
        col = pow(clamp(col, 0.0, 1.0), vec3(GBA_GAMMA / 2.2));
    }

    // [3] Luma Softening (تنعيم الحواف الأفقي)
    // لقراءة البكسلات الجانبية وتنعيم الصورة
    vec3 cL = texture(Texture, uv - ps * vec2(1.0, 0.0)).rgb;
    vec3 cR = texture(Texture, uv + ps * vec2(1.0, 0.0)).rgb;
    col = mix(col, (cL + cR) * 0.5, EDGE_SOFT * 0.6);

    FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
#endif