// --- PRO CRT ENGINE V18.2 (FLAT GEOMETRY - FIXED SYNTAX) ---
// تم تعديل خيار الإيقاف ليكون 0 والحفاظ على كافة المزايا والألوان

#version 110

#ifdef GL_ES
precision highp float;
#endif

// --- 1. إعدادات الـ Multi-LUT (تم تعديل الترتيب: 0 هو الإيقاف) ---
#pragma parameter SELECT_LUT "Select LUT: 0:Off, 1:L1, 2:L2, 3:L3" 1.0 0.0 3.0 1.0
#pragma parameter LUT_Size "LUT Size (16, 32, 64)" 32.0 16.0 64.0 16.0
#pragma parameter LUT_Amount "LUT Intensity" 1.0 0.0 1.0 0.05

// --- 2. الإضاءة والألوان (Physical Realism) ---
#pragma parameter g_lum "Brightness" 0.0 -0.5 1.0 0.02
#pragma parameter g_cntrst "Contrast" 1.0 0.5 2.0 0.05
#pragma parameter g_blk "Royale Black Depth" 0.0 0.0 1.0 0.05
#pragma parameter g_blk_f "Black Falloff (S-Curve)" 3.5 1.0 10.0 0.5
#pragma parameter g_sat "Saturation" 1.0 0.0 2.0 0.05
#pragma parameter g_gamma "CRT Gamma" 2.4 1.5 3.5 0.1
#pragma parameter g_hue "NTSC Hue" 0.0 -30.0 30.0 1.0
#pragma parameter C_PROFILE "Color Profile: 0:Off, 1:PAL, 2:NTSC-J, 3:US, 4:Trini" 0.0 0.0 4.0 1.0

// --- 3. إعدادات السواد فقط (Vignette) ---
#pragma parameter v_softness "Vignette Softness" 0.10 0.0 0.30 0.01
#pragma parameter v_amount "Vignette Strength" 0.5 0.0 1.0 0.05

// --- 4. إعدادات الواقعية المتقدمة ---
#pragma parameter g_noise "Phosphor Grain (Realism)" 0.03 0.0 0.15 0.01
#pragma parameter CRT_GLOW "Physical Glow Strength" 0.0 0.0 1.0 0.02
#pragma parameter HALATION "Halation (Afterglow)" 0.0 0.0 1.0 0.05

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
uniform mat4 MVPMatrix;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
}

#elif defined(FRAGMENT)
uniform sampler2D Texture;
uniform sampler2D LUT1, LUT2, LUT3; 
uniform vec2 TextureSize;
uniform vec2 InputSize;
varying vec2 vTexCoord;

#ifdef PARAMETER_UNIFORM
uniform float SELECT_LUT, LUT_Size, LUT_Amount;
uniform float g_lum, g_cntrst, g_blk, g_blk_f, g_sat, g_gamma, g_hue, C_PROFILE;
uniform float v_softness, v_amount;
uniform float g_noise, CRT_GLOW, HALATION;
#endif

float hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

vec3 apply_lut(vec3 color, sampler2D lut, float size) {
    float sliceSize = 1.0 / size;
    float sliceInnerSize = sliceSize * (size - 1.0);
    float zSlice0 = min(floor(color.b * (size - 1.0)), size - 1.0);
    float zSlice1 = min(zSlice0 + 1.0, size - 1.0);
    float xOffset = (sliceSize * 0.5) / size + color.r * (sliceInnerSize / size);
    float yOffset = sliceSize * 0.5 + color.g * (1.0 - sliceSize);
    vec2 uv0 = vec2(zSlice0 * sliceSize + xOffset, yOffset);
    vec2 uv1 = vec2(zSlice1 * sliceSize + xOffset, yOffset);
    return mix(texture2D(lut, uv0).rgb, texture2D(lut, uv1).rgb, fract(color.b * (size - 1.0)));
}

vec3 apply_hue(vec3 color, float h) {
    float angle = h * 0.01745329;
    float s = sin(angle); float c = cos(angle);
    vec3 w = vec3(0.299, 0.587, 0.114);
    float luma = dot(color, w);
    return mix(vec3(luma), color, c) + cross(w, color) * s;
}

void main() {
    vec2 scale = TextureSize / InputSize;
    vec2 texcoord = (vTexCoord * scale) - vec2(0.5);
    vec2 final_uv = (texcoord + vec2(0.5)) / scale;
    vec3 color = texture2D(Texture, final_uv).rgb;

    // 1. Multi-LUT Logic (0: Off, 1: LUT1, 2: LUT2, 3: LUT3)
    if (SELECT_LUT > 0.5) {
        vec3 lut_col;
        if (SELECT_LUT < 1.5)      lut_col = apply_lut(color, LUT1, LUT_Size);
        else if (SELECT_LUT < 2.5) lut_col = apply_lut(color, LUT2, LUT_Size);
        else                       lut_col = apply_lut(color, LUT3, LUT_Size);
        color = mix(color, lut_col, LUT_Amount);
    }

    // 2. Royale Black
    if (g_blk > 0.0) {
        color = mix(color, pow(max(color, 0.01), vec3(g_blk_f)), g_blk);
    }

    // 3. Profiles & Color
    if (C_PROFILE == 1.0)      color *= vec3(1.0, 0.92, 0.88);
    else if (C_PROFILE == 2.0) color *= vec3(0.92, 0.95, 1.15);
    else if (C_PROFILE == 3.0) color *= vec3(1.08, 1.0, 0.92);
    else if (C_PROFILE == 4.0) color *= vec3(1.02, 1.10, 1.05);

    color = apply_hue(color, g_hue);
    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luma), color, g_sat);
    color = (color - 0.5) * g_cntrst + 0.5 + g_lum;

    // 4. Noise & Vignette
    color += (hash(final_uv) - 0.5) * g_noise;
    float fade_x = smoothstep(0.5, 0.5 - v_softness, abs(texcoord.x));
    float fade_y = smoothstep(0.5, 0.5 - v_softness, abs(texcoord.y));
    color *= mix(1.0, fade_x * fade_y, v_amount);

    // 5. Glow & Halation
    vec3 glow = (color * color) * CRT_GLOW;
    color += glow;
    if (HALATION > 0.0) color += (color * color) * HALATION;

    // 6. Final Gamma Correction
    gl_FragColor = vec4(pow(clamp(color, 0.0, 1.0), vec3(g_gamma / 2.2)), 1.0);
}
#endif