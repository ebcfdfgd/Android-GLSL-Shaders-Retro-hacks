// --- NTSC MEGA FUSION EXTREME (DariusG + Rainbow + De-Dither + Grain + Ghosting) ---
// Optimized for Android - Combined by Gemini 2026 - (No Scanlines Version)

#version 110

#pragma parameter ntsc_hue "NTSC Color Hue (Cyan Fix)" 0.0 -3.14 3.14 0.05
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.2 0.0 20.0 0.05
#pragma parameter rb_power "Rainbow Strength" 0.10 0.0 2.0 0.05
#pragma parameter rb_size "Rainbow Width" 5.0 0.5 6.0 0.1
#pragma parameter rb_detect "Rainbow Detection" 0.60 0.0 1.0 0.01
#pragma parameter de_dither "MD De-Dither (Sonic Water)" 1.0 0.0 2.0 0.1
#pragma parameter ntsc_grain "Signal Grain (RF Noise)" 0.01 0.0 0.20 0.01
#pragma parameter ghosting "Signal Ghosting (Ringing)" 0.3 0.0 1.0 0.05
#pragma parameter tv_mist "TV Signal Mist (Blur)" 0.1 0.0 1.5 0.05

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
uniform mat4 MVPMatrix;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

uniform sampler2D Texture;
uniform vec2 TextureSize;
varying vec2 vTexCoord;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_hue, COL_BLEED, rb_power, rb_size, rb_detect, de_dither, ntsc_grain, ghosting, tv_mist;
#endif

// Fast Noise for Signal Grain
float noise(vec2 co) {
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

mat3 RGBtoYIQ = mat3(0.2989, 0.5870, 0.1140, 0.5959, -0.2744, -0.3216, 0.2115, -0.5229, 0.3114);
mat3 YIQtoRGB = mat3(1.0, 0.956, 0.6210, 1.0, -0.2720, -0.6474, 1.0, -1.1060, 1.7046);

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 0.0);
    float bleed = ps.x * COL_BLEED;

    // --- 1. SIGNAL GHOSTING (Ringing Effect) ---
    vec3 main_col = texture2D(Texture, vTexCoord).rgb;
    vec3 ghost_col = texture2D(Texture, vTexCoord - ps * 2.0).rgb;
    vec3 col = mix(main_col, ghost_col, ghosting * 0.4);

    // --- 2. MEGA DRIVE DE-DITHER (Blend patterns) ---
    vec3 c_left = texture2D(Texture, vTexCoord - ps * de_dither).rgb;
    vec3 c_right = texture2D(Texture, vTexCoord + ps * de_dither).rgb;
    col = (col * 0.5) + (c_left * 0.25) + (c_right * 0.25);

    // --- 3. DARIUSG CHROMA BLEED ---
    vec3 res    = col * RGBtoYIQ;
    vec3 resr   = texture2D(Texture, vTexCoord - vec2(2.0*bleed, 0.0)).rgb * RGBtoYIQ;
    vec3 resru  = texture2D(Texture, vTexCoord - ps).rgb * RGBtoYIQ;
    vec3 resrr  = texture2D(Texture, vTexCoord - vec2(3.0*bleed, 0.0)).rgb * RGBtoYIQ;
    vec3 resl   = texture2D(Texture, vTexCoord + vec2(2.0*bleed, 0.0)).rgb * RGBtoYIQ;
    vec3 reslu  = texture2D(Texture, vTexCoord + bleed).rgb * RGBtoYIQ;
    vec3 resll  = texture2D(Texture, vTexCoord + vec2(3.0*bleed, 0.0)).rgb * RGBtoYIQ;

    vec2 mixed_chroma = (res.gb + resr.gb + resl.gb + resrr.gb + resll.gb + reslu.gb + resru.gb) / 7.0;

    // --- 4. RAINBOW DETECTION & GENERATION ---
    float lC = res.r;
    float lL = resru.r;
    float lR = (texture2D(Texture, vTexCoord + ps).rgb * RGBtoYIQ).r;
    float diff = abs(lC - lL) + abs(lC - lR);
    float rb_mask = smoothstep(rb_detect, rb_detect + 0.1, diff);

    float x_pos = vTexCoord.x * TextureSize.x;
    float angle = (x_pos / rb_size) + ntsc_hue;
    float rainbowI = sin(angle) * rb_power * rb_mask;
    float rainbowQ = cos(angle) * rb_power * rb_mask;

    // --- 5. TV SIGNAL MIST & GRAIN ---
    float final_y = mix(res.r, (lL + lC + lR) / 3.0, tv_mist);
    final_y += (noise(vTexCoord) - 0.5) * ntsc_grain;

    // --- 6. HUE SHIFT & FINAL ASSEMBLY ---
    float cosA = cos(ntsc_hue);
    float sinA = sin(ntsc_hue);
    
    float finalI = mixed_chroma.x + rainbowI;
    float finalQ = mixed_chroma.y + rainbowQ;
    
    float hueI = finalI * cosA - finalQ * sinA;
    float hueQ = finalI * sinA + finalQ * cosA;

    vec3 final_rgb = vec3(final_y, hueI, hueQ) * YIQtoRGB;

    gl_FragColor = vec4(clamp(final_rgb, 0.0, 1.0), 1.0);
}
#endif