#version 110

/* LIGHT-ULTIMATE (Direct Sampling Edition)
    - REMOVED: Quilez Scaling (Replaced with Raw Direct Sampling).
    - OPTIMIZED: Clean pipeline, high-speed texture sampling.
    - CORE: Full Image Display + Zoom + Master Brightness Boost + L1 Blending.
*/

// --- PARAMETERS ---
#pragma parameter ZOOM "Zoom Amount" 1.0 0.5 2.0 0.01
#pragma parameter BRIGHT_BOOST "Brightness Boost" 1.2 1.0 5.0 0.05

// L1: Multiply
#pragma parameter OverlayMix "L1 Intensity (Multiply)" 1.0 0.0 1.0 0.05
#pragma parameter LUTWidth "L1 Width" 6.0 1.0 1024.0 1.0
#pragma parameter LUTHeight "L1 Height" 4.0 1.0 1024.0 1.0

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec4 TexCoord;
varying vec2 TEX0;
uniform mat4 MVPMatrix;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    TEX0 = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

varying vec2 TEX0;
uniform vec2 OutputSize;
uniform sampler2D Texture, overlay;

#ifdef PARAMETER_UNIFORM
uniform float ZOOM, BRIGHT_BOOST, OverlayMix, LUTWidth, LUTHeight;
#endif

void main() {
    // 1. حساب الإحداثيات (Full Image)
    // نستخدم (TEX0 - 0.5) لضبط المركز، ثم نقسم على Zoom للتكبير، ونعيد الإزاحة
    vec2 uv = (TEX0 - 0.5) / ZOOM + 0.5;
    
    // 2. Direct Sampling (Raw)
    // سحب مباشر من النسيج بدون أي عمليات Scaling إضافية
    vec3 gm = texture2D(Texture, uv).rgb;

    // 3. Blending Logic (L1 Multiply)
    // حساب موقع القناع بناءً على دقة الشاشة
    vec2 maskUV1 = vec2(fract(TEX0.x * OutputSize.x / LUTWidth), fract(TEX0.y * OutputSize.y / LUTHeight));
    vec3 m1 = texture2D(overlay, maskUV1).rgb;
    
    // تطبيق الدمج
    gm = mix(gm, gm * m1, OverlayMix);

    // 4. Final Output (Master Gain)
    gl_FragColor = vec4(clamp(gm * BRIGHT_BOOST, 0.0, 1.0), 1.0);
}
#endif