// --- Blargg Ultra-Lite (1000 Logic Merge + RF Grain) ---
// Optimization: Smart Bypass on Zero Parameters + Added Saturation & Black Level
#version 110

#pragma parameter ntsc_hue "NTSC Phase Shift" 0.0 -3.14 3.14 0.05
#pragma parameter SATURATION "Saturation" 1.0 0.0 2.0 0.05
#pragma parameter BLACK_LEVEL "Black Level" 0.0 -0.5 0.5 0.01
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.5 0.0 5.0 0.1
#pragma parameter rb_global_strength "Rainbow Master Power" 1.0 0.0 5.0 0.1
#pragma parameter rb_power "Rainbow Transparency (Mix)" 0.35 0.0 2.0 0.01
#pragma parameter dot_crawl "Dot Crawl Intensity" 0.25 0.0 1.0 0.01
#pragma parameter de_dither "Dither Blending Strength" 0.50 0.0 1.0 0.01
#pragma parameter pi_mod "Subcarrier Phase Angle" 131.5 0.0 360.0 0.1
#pragma parameter vert_scal "Vertical Phase Scale" 0.5 0.0 2.0 0.01
#pragma parameter sig_noise "Signal RF Grain" 0.04 0.0 10.2 0.01

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
varying vec2 hue_trig; 
uniform mat4 MVPMatrix;
uniform float ntsc_hue;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
    hue_trig = vec2(cos(ntsc_hue), sin(ntsc_hue));
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;
varying vec2 vTexCoord;
varying vec2 hue_trig;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_hue, SATURATION, BLACK_LEVEL, COL_BLEED, rb_global_strength, rb_power, dot_crawl, de_dither, pi_mod, vert_scal;
uniform float sig_noise;
#endif

#define PI 3.14159265

// RF Grain Hash
float hash(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }

void main() {
    vec3 col_m = texture2D(Texture, vTexCoord).rgb;
    float time = float(FrameCount);

    // --- نظام الإيقاف الذكي (BYPASS) ---
    if (rb_power <= 0.0 && dot_crawl <= 0.0 && sig_noise <= 0.0 && COL_BLEED <= 0.0 && de_dither <= 0.0 && SATURATION == 1.0 && BLACK_LEVEL == 0.0) {
        gl_FragColor = vec4(col_m, 1.0);
        return; 
    }

    vec2 ps = 1.0 / TextureSize;
    
    // --- 1. FETCH SURROUNDINGS ---
    vec2 d_off = ps * max(de_dither, 1.0);
    vec3 col_l = texture2D(Texture, vTexCoord - d_off).rgb;
    vec3 col_r = texture2D(Texture, vTexCoord + d_off).rgb;

    float y_m = dot(col_m, vec3(0.299, 0.587, 0.114));
    float y_l = dot(col_l, vec3(0.299, 0.587, 0.114));
    float y_r = dot(col_r, vec3(0.299, 0.587, 0.114));

    // --- 2. DITHER & RAINBOW DETECTION ---
    float edge = abs(y_l - y_m) + abs(y_r - y_m) - abs(y_l - y_r);
    float rb_mask = smoothstep(0.02, 0.22, edge);

    float final_y = mix(y_m, (y_l + y_m + y_r) * 0.3333, de_dither * rb_mask);

    // --- 3. NTSC PHASE, DOT CRAWL & ARTIFACTS ---
    float x_c = floor(vTexCoord.x * TextureSize.x);
    float y_c = floor(vTexCoord.y * TextureSize.y);
    float phase = (x_c * pi_mod * 0.01745) + (y_c * vert_scal * PI) + (mod(time, 2.0) * PI);
    
    final_y += sin(phase) * dot_crawl * rb_mask;
    
    if (sig_noise > 0.0) final_y += (hash(vTexCoord + time * 0.01) - 0.5) * sig_noise;

    // --- 4. CHROMA & RAINBOW ENGINE ---
    float i = dot(col_m, vec3(0.5957, -0.2744, -0.3212));
    float q = dot(col_m, vec3(0.2114, -0.5227, 0.3113));

    if (rb_power > 0.0) {
        float rb_i = sin(phase) * rb_mask * rb_global_strength;
        float rb_q = cos(phase) * rb_mask * rb_global_strength;
        i = mix(i, i + rb_i, rb_power);
        q = mix(q, q + rb_q, rb_power);
    }

    // --- 5. CHROMA BLEED ---
    if (COL_BLEED > 0.0) {
        float bleed_step = ps.x * COL_BLEED;
        vec3 col_bleed_l = texture2D(Texture, vTexCoord - vec2(bleed_step, 0.0)).rgb;
        vec3 col_bleed_r = texture2D(Texture, vTexCoord + vec2(bleed_step, 0.0)).rgb;
        
        float i_l = dot(col_bleed_l, vec3(0.5957, -0.2744, -0.3212));
        float i_r = dot(col_bleed_r, vec3(0.5957, -0.2744, -0.3212));
        float q_l = dot(col_bleed_l, vec3(0.2114, -0.5227, 0.3113));
        float q_r = dot(col_bleed_r, vec3(0.2114, -0.5227, 0.3113));

        i = mix(i, (i_l + i_r) * 0.5, 0.5);
        q = mix(q, (q_l + q_r) * 0.5, 0.5);
    }

    // --- 6. HUE SHIFT, SATURATION & FINAL ASSEMBLY ---
    float fI = (i * hue_trig.x - q * hue_trig.y) * SATURATION;
    float fQ = (i * hue_trig.y + q * hue_trig.x) * SATURATION;

    vec3 rgb = vec3(
        final_y + 0.9563 * fI + 0.6210 * fQ,
        final_y - 0.2721 * fI - 0.6474 * fQ,
        final_y - 1.1070 * fI + 1.7046 * fQ
    );
    
    // --- 7. APPLY BLACK LEVEL ---
    rgb = mix(vec3(BLACK_LEVEL), vec3(1.0), rgb);
    
    gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
#endif