#version 130

// --- VERTEX SHADER ---
#if defined(VERTEX)
in vec4 VertexCoord;
in vec2 TexCoord;
out vec2 TEX0;
out vec2 vTexCoord;
uniform mat4 MVPMatrix;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    TEX0 = TexCoord; 
    vTexCoord = TexCoord; 
}

// --- FRAGMENT SHADER ---
#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

in vec2 TEX0;
in vec2 vTexCoord;
out vec4 FragColor;

#if __VERSION__ >= 130
#define COMPAT_TEXTURE texture
#else
#define COMPAT_TEXTURE texture2D
#endif

uniform sampler2D Texture;       
uniform sampler2D OverlayTexture; 
uniform sampler2D OverlayTexture2; 
uniform vec2 TextureSize;
uniform vec2 InputSize;
uniform vec2 OutputSize;

// --- إعدادات الصورة العامة ---
#pragma parameter GAME_ZOOM "Game Zoom Scale" 1.0 0.5 2.0 0.001
#pragma parameter BRIGHT_BOOST "Final Bright Boost" 1.2 1.0 5.0 0.05
#pragma parameter BARREL_DISTORTION "Lens Curve Amount" 0.12 0.0 0.5 0.01

// --- ميزة Vignette من كود 63 ---
#pragma parameter v_softness "Vignette Softness" 0.10 0.0 0.30 0.01
#pragma parameter v_amount "Vignette Strength" 0.5 0.0 1.0 0.05

// --- إعدادات الطبقة الأولى (L1) ---
#pragma parameter blend_mode "L1 Mode: Mult, Over, Soft, Vivid, SUB, DODGE, DARK" 0.0 0.0 6.0 1.0
#pragma parameter overlay_str "L1 PNG Intensity" 0.35 0.0 1.0 0.05
#pragma parameter zoom_overlay "L1 PNG Scale" 1.0 0.1 10.0 0.1
#pragma parameter png_width "L1 PNG Width" 6.0 1.0 1024.0 1.0
#pragma parameter png_height "L1 PNG Height" 4.0 1.0 1024.0 1.0

// --- إعدادات الطبقة الثانية (L2) ---
#pragma parameter blend_mode2 "L2 Mode: Mult, Over, Soft, Vivid, SUB, DODGE, DARK" 0.0 0.0 6.0 1.0
#pragma parameter overlay_str2 "L2 PNG Intensity" 0.20 0.0 1.0 0.05
#pragma parameter zoom_overlay2 "L2 PNG Scale" 1.0 0.1 10.0 0.1
#pragma parameter png_width2 "L2 PNG Width" 6.0 1.0 1024.0 1.0
#pragma parameter png_height2 "L2 PNG Height" 4.0 1.0 1024.0 1.0

#ifdef PARAMETER_UNIFORM
uniform float GAME_ZOOM, BRIGHT_BOOST, BARREL_DISTORTION, v_softness, v_amount, blend_mode, overlay_str, zoom_overlay, png_width, png_height;
uniform float blend_mode2, overlay_str2, zoom_overlay2, png_width2, png_height2;
#endif

vec3 blend_logic(vec3 a, vec3 b, float mode) {
    if (mode < 0.5) return a * b; // Multiply
    if (mode < 1.5) return mix(2.0 * a * b, 1.0 - 2.0 * (1.0 - a) * (1.0 - b), step(0.5, a.r)); // Overlay
    if (mode < 2.5) return (1.0 - 2.0 * b) * a * a + 2.0 * b * a; // Soft Light
    if (mode < 3.5) return abs(a - b); // Vivid/Difference
    if (mode < 4.5) return clamp(a - b, 0.0, 1.0); // Subtract
    if (mode < 5.5) return a / (1.00001 - b); // Color Dodge
    return min(a, b); // Darken
}

void main() {
    // --- معادلة فرش التكتشر من كود 63 بالملي ---
    vec2 sc = TextureSize / InputSize;
    vec2 mP = TEX0.xy * TextureSize / InputSize; 
    
    // --- تطبيق الزوم والكيرف للصورة الأصلية ---
    vec2 uv = (TEX0.xy * sc) - 0.5;
    uv /= GAME_ZOOM; 
    vec2 d_uv = uv + (uv * (BARREL_DISTORTION * dot(uv, uv)));
    d_uv *= (1.0 - (0.18 * BARREL_DISTORTION)); // تصحيح الأطراف
    
    // --- رسم حدود الشاشة والسواد ---
    float edge = smoothstep(0.5, 0.498, abs(d_uv.x)) * smoothstep(0.5, 0.498, abs(d_uv.y));
    
    if (edge <= 0.0) {
        FragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // سحب لون اللعبة
    vec2 fetch_uv = (d_uv + 0.5) / sc;
    vec3 game = COMPAT_TEXTURE(Texture, fetch_uv).rgb * BRIGHT_BOOST * edge;

    // --- تطبيق ميزة Vignette من كود 63 لتعمل مع الكيرف ---
    float fade_x = smoothstep(0.5, 0.5 - v_softness, abs(d_uv.x));
    float fade_y = smoothstep(0.5, 0.5 - v_softness, abs(d_uv.y));
    game *= mix(1.0, fade_x * fade_y, v_amount);

    // --- تطبيق معادلة 63 لفرش الأوفرلاي (L1) ---
    vec2 maskUV1 = vec2(fract(mP.x * OutputSize.x / (png_width * zoom_overlay)), 
                        fract(mP.y * OutputSize.y / (png_height * zoom_overlay)));
    vec3 png1 = COMPAT_TEXTURE(OverlayTexture, maskUV1).rgb;

    // --- تطبيق معادلة 63 لفرش الأوفرلاي (L2) ---
    vec2 maskUV2 = vec2(fract(mP.x * OutputSize.x / (png_width2 * zoom_overlay2)), 
                        fract(mP.y * OutputSize.y / (png_height2 * zoom_overlay2)));
    vec3 png2 = COMPAT_TEXTURE(OverlayTexture2, maskUV2).rgb;

    // --- الدمج النهائي المعتمد ---
    vec3 r1 = mix(game, clamp(blend_logic(game, png1, blend_mode), 0.0, 1.0), overlay_str);
    vec3 r2 = mix(r1, clamp(blend_logic(r1, png2, blend_mode2), 0.0, 1.0), overlay_str2);

    FragColor = vec4(clamp(r2, 0.0, 1.0), 1.0);
}
#endif