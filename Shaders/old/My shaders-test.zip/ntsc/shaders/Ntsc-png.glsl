#version 100
precision mediump float;

// --- الباراميترز الأصلية ---
#pragma parameter rb_opacity "Rainbow Intensity" 0.1 0.0 2.0 0.01
#pragma parameter rb_threshold "Detection Sensitivity" 0.35 0.0 0.8 0.01 
#pragma parameter rb_zoom "Rainbow Scale" 10.0 0.1 50.0 0.1
#pragma parameter rb_speed "Animation Speed" 0.0 0.0 4.0 0.01
#pragma parameter rb_sat "Rainbow Saturation" 1.0 -0.5 5.0 0.05
#pragma parameter de_dither "MD De-Dither (Sonic Water)" 0.7 0.0 2.0 0.1
#pragma parameter NOISE_STR "Analog Signal Noise" 0.00 0.0 0.5 0.01
#pragma parameter ghosting "Signal Ghosting (Ringing)" 0.1 0.0 1.0 0.05
#pragma parameter tv_mist "TV Signal Mist (Blur)" 0.1 0.0 1.5 0.05
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.2 0.0 20.0 0.05
#pragma parameter rb_tex_sel "Select Texture (0:PNG2, 1:PNG3)" 0.0 0.0 1.0 1.0
#pragma parameter horiz_sharp "Horizontal Sharpen" 0.3 0.0 2.0 0.05

// --- المزايا المضافة حديثاً ---
#pragma parameter CRAWL_SPEED "Rainbow Crawl Speed" 0.0 0.0 2.0 0.001
#pragma parameter JITTER "Signal Jitter (Shake)" 0.01 0.0 0.5 0.01
#pragma parameter ntsc_hue "NTSC Hue (Tint)" 0.0 -0.5 0.5 0.02

#ifdef VERTEX
attribute vec4 VertexCoord;
attribute vec4 TexCoord;
varying vec2 TEX0;
varying vec2 vRainbowUV;
uniform mat4 MVPMatrix;
uniform vec2 TextureSize;
uniform vec2 InputSize;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    TEX0 = TexCoord.xy;
    vRainbowUV = TexCoord.xy * (TextureSize / 256.0) * (InputSize / TextureSize);
}
#endif

#ifdef FRAGMENT
varying vec2 TEX0;
varying vec2 vRainbowUV;
uniform sampler2D Texture;
uniform sampler2D PNG2;
uniform sampler2D PNG3;
uniform int FrameCount;
uniform vec2 TextureSize;

uniform float rb_opacity, rb_threshold, rb_zoom, rb_speed, rb_sat, de_dither, NOISE_STR, ghosting, tv_mist, COL_BLEED, rb_tex_sel, horiz_sharp;
uniform float CRAWL_SPEED, JITTER, ntsc_hue;

#define RGB_TO_YIQ(c) vec3(dot(c, vec3(0.2989, 0.5870, 0.1140)), dot(c, vec3(0.5959, -0.2744, -0.3216)), dot(c, vec3(0.2115, -0.5229, 0.3114)))
float rand(vec2 co){ return fract(sin(dot(co.xy ,vec2(12.98, 78.23))) * 437.5); }

void main() {
    float time = float(FrameCount);
    vec2 ps = vec2(1.0 / TextureSize.x, 1.0 / TextureSize.y);
    
    // 1. JITTER
    vec2 uv = TEX0;
    if(JITTER > 0.0) {
        uv.x += (rand(vec2(time, TEX0.y)) - 0.5) * JITTER * ps.x;
    }

    float bleed = ps.x * COL_BLEED;
    
    // 2. SIGNAL PROCESSING
    vec3 main_col = texture2D(Texture, uv).rgb;
    vec3 ghost_col = texture2D(Texture, uv - ps * 2.0).rgb;
    vec3 c_left  = texture2D(Texture, uv - ps * de_dither).rgb;
    vec3 c_right = texture2D(Texture, uv + ps * de_dither).rgb;
    
    vec3 col = mix(main_col, ghost_col, ghosting * 0.4);
    col = (col * 0.5) + (c_left * 0.25) + (c_right * 0.25);

    // 3. CHROMA MIXING (YIQ) - الـ 7 عينات
    vec3 res   = RGB_TO_YIQ(col);
    vec3 resr  = RGB_TO_YIQ(texture2D(Texture, uv - vec2(2.0*bleed, 0.0)).rgb);
    vec3 resrr = RGB_TO_YIQ(texture2D(Texture, uv - vec2(3.0*bleed, 0.0)).rgb);
    vec3 resl  = RGB_TO_YIQ(texture2D(Texture, uv + vec2(2.0*bleed, 0.0)).rgb);
    vec3 resll = RGB_TO_YIQ(texture2D(Texture, uv + vec2(3.0*bleed, 0.0)).rgb);
    vec3 resru = RGB_TO_YIQ(texture2D(Texture, uv - ps).rgb);
    vec3 reslu = RGB_TO_YIQ(texture2D(Texture, uv + bleed).rgb);

    vec2 mixed_chroma = (res.gb + resr.gb + resl.gb + resrr.gb + resll.gb + reslu.gb + resru.gb) / 7.0;

    // --- تطبيق NTSC HUE (Rotation) ---
    float hue_sin = sin(ntsc_hue);
    float hue_cos = cos(ntsc_hue);
    mixed_chroma = vec2(mixed_chroma.x * hue_cos - mixed_chroma.y * hue_sin, 
                        mixed_chroma.x * hue_sin + mixed_chroma.y * hue_cos);

    // 4. WATERFALL & SHARPENING
    float yC = res.r;
    float yL = dot(texture2D(Texture, uv - ps).rgb, vec3(0.299, 0.587, 0.114));
    float yR = dot(texture2D(Texture, uv + ps).rgb, vec3(0.299, 0.587, 0.114));
    
    float sharp_y = yC + (yC * 2.0 - yL - yR) * horiz_sharp;
    float diff = abs(yC - yL) + abs(yC - yR);

    // 5. MIST & NOISE
    float mask = clamp(diff - rb_threshold, 0.0, 1.0) * 5.0;
    float final_y = mix(sharp_y, (yL + yC + yR) / 3.0, tv_mist);
    if(NOISE_STR > 0.0) final_y += (rand(uv + time * 0.01) - 0.5) * NOISE_STR;

    // 6. RAINBOW PNG PROCESSING
    vec2 pUV = vRainbowUV / rb_zoom;
    pUV.x += (time * rb_speed * 0.02) + (time * CRAWL_SPEED * 0.1); 
    pUV.y += mod(time, 2.0) * 0.5;

    vec3 pngCol = (rb_tex_sel < 0.5) ? texture2D(PNG2, fract(pUV)).rgb : texture2D(PNG3, fract(pUV)).rgb;
    float pngGray = dot(pngCol, vec3(0.299, 0.587, 0.114));
    pngCol = mix(vec3(pngGray), pngCol, rb_sat);

    // 7. FINAL ASSEMBLY
    vec3 final_rgb;
    final_rgb.r = final_y + 0.9563 * mixed_chroma.x + 0.6210 * mixed_chroma.y;
    final_rgb.g = final_y - 0.2721 * mixed_chroma.x - 0.6474 * mixed_chroma.y;
    final_rgb.b = final_y - 1.1070 * mixed_chroma.x + 1.7046 * mixed_chroma.y;

    vec3 result = mix(final_rgb, pngCol, mask * rb_opacity);

    gl_FragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
#endif