#version 130
/* 60-PRINCE-ULTIMATE-COMBINED (COLOR FIXED)
   - Precise Subpixel & Grid
   - Smart Color Balance (Anti-Green Fixed)
   - Edge Softening (AA) Integrated
   - Optimized for Mali/Adreno
*/

#if defined(VERTEX)
in vec4 VertexCoord, TexCoord;
out vec2 vTexCoord, pix_coord;
uniform mat4 MVPMatrix;
uniform vec2 TextureSize;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
    pix_coord = vTexCoord * TextureSize;
}

#elif defined(FRAGMENT)
precision highp float;
in vec2 vTexCoord, pix_coord;
out vec4 FragColor;

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;

#pragma parameter GRID_STR "LCD Grid Intensity" 0.5 0.0 1.0 0.05
#pragma parameter SUBPIX_STR "Subpixel Strength" 0.6 0.0 1.0 0.05
#pragma parameter EDGE_SOFT "Edge Softening (AA)" 0.3 0.0 1.0 0.05
#pragma parameter BRIGHTNESS "Overall Brightness" 1.1 0.5 2.0 0.05
#pragma parameter PROFILE "Color Profile: 0:Off, 1:GBA, 2:GBC, 3:SP, 4:GG, 5:GBG, 6:101" 1.0 0.0 6.0 1.0
#pragma parameter LCD_GRAIN "LCD Plastic Grain" 0.15 0.0 0.50 0.05
#pragma parameter GHOST_STR "LCD Ghosting" 0.45 0.0 1.0 0.05
#pragma parameter MOTION_OFS "Motion Spread" 0.7 0.0 2.0 0.05
#pragma parameter SATURATION "Saturation" 1.1 0.0 2.0 0.05
#pragma parameter CONTRAST "Contrast" 1.15 0.5 2.0 0.05
#pragma parameter GAMMA_IN "Gamma In" 1.10 0.5 3.0 0.05

#ifdef PARAMETER_UNIFORM
uniform float GRID_STR, SUBPIX_STR, EDGE_SOFT, BRIGHTNESS, PROFILE, LCD_GRAIN;
uniform float GHOST_STR, MOTION_OFS, SATURATION, CONTRAST, GAMMA_IN;
#endif

float pseudo_noise(vec2 co) {
    return fract(sin(dot(co.xy, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 ps = 1.0 / TextureSize;
    vec2 uv = vTexCoord;
    float time = float(FrameCount);
    
    // [0] Edge Softening (تنعيم الحواف قبل البدء)
    vec3 col = texture(Texture, uv).rgb;
    if (EDGE_SOFT > 0.0) {
        vec3 avg = (texture(Texture, uv + vec2(ps.x, 0.0)).rgb + 
                    texture(Texture, uv - vec2(ps.x, 0.0)).rgb + 
                    texture(Texture, uv + vec2(0.0, ps.y)).rgb + 
                    texture(Texture, uv - vec2(0.0, ps.y)).rgb) * 0.25;
        col = mix(col, avg, EDGE_SOFT * 0.5);
    }
    
    // [1] Ghosting
    if (GHOST_STR > 0.0) {
        float toggle = (mod(time, 2.0) > 0.5) ? 1.0 : -1.0;
        float off = MOTION_OFS * 0.7;
        vec3 s1 = texture(Texture, uv + (ps * off)).rgb;
        vec3 s2 = texture(Texture, uv - (ps * off)).rgb;
        col = mix(col, (s1 + s2) * 0.5, GHOST_STR * 0.65);
    }

    // [2] Color Profiles
    if (PROFILE > 0.5) {
        if (PROFILE < 1.5)      col *= mat3(0.84, 0.08, 0.08, 0.14, 0.86, 0.14, 0.02, 0.06, 0.78);
        else if (PROFILE < 2.5) col *= mat3(0.70, 0.20, 0.10, 0.15, 0.70, 0.15, 0.15, 0.10, 0.75);
        else if (PROFILE < 3.5) { col *= mat3(0.75, 0.15, 0.10, 0.10, 0.75, 0.15, 0.15, 0.20, 0.65); col.b += 0.05; }
        else if (PROFILE < 4.5) { col *= mat3(0.85, 0.10, 0.05, 0.10, 0.85, 0.10, 0.05, 0.10, 0.85); col += 0.03; }
        else if (PROFILE < 5.5) { col = mix(vec3(0.05, 0.1, 0.05), vec3(0.6, 0.75, 0.1), dot(col, vec3(0.299, 0.587, 0.114))); }
        else { col *= mat3(0.90, 0.05, 0.05, 0.05, 0.90, 0.05, 0.05, 0.05, 0.95); }
    }

    // [3] Image Correction
    col = pow(max(col, 0.0), vec3(GAMMA_IN));
    col = (col - 0.5) * CONTRAST + 0.5;
    col = mix(vec3(dot(col, vec3(0.21, 0.72, 0.07))), col, SATURATION);

    // [4] Prince Logic (FIXED GREEN MASK)
    vec2 subpix_pos = fract(pix_coord);
    vec2 grid = smoothstep(0.5 - GRID_STR * 0.5, 0.5 + GRID_STR * 0.5, abs(subpix_pos - 0.5));
    float mask = 1.0 - max(grid.x, grid.y);

    float x_offset = subpix_pos.x * 3.0;
    vec3 weights;
    weights.r = clamp(1.0 - abs(x_offset - 0.5), 0.0, 1.0);
    weights.g = clamp(1.0 - abs(x_offset - 1.5), 0.0, 1.0) * 0.80; 
    weights.b = clamp(1.0 - abs(x_offset - 2.5), 0.0, 1.0) * 1.10;
    
    vec3 subpixel = mix(vec3(1.0), weights * 1.5, SUBPIX_STR);

    // [5] Noise & Final Mix
    float noise = pseudo_noise(uv * TextureSize);
    col = mix(col, col * (0.9 + 0.2 * noise), LCD_GRAIN);
    
    col *= mask;
    col *= subpixel;
    col *= BRIGHTNESS;

    FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
#endif