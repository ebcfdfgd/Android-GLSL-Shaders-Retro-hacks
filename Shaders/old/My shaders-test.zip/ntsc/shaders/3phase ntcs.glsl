// --- NTSC-NES-CLEAN-V16-MOD-MIST ---
// Rainbow + Chroma Shift + 3-Phase + TV Mist
// Optimized for Android 2026 - Pure Retro Performance

#version 110

// القائمة المحدثة ببارامتر الضبابية
#pragma parameter ntsc_art "Rainbow Strength" 0.7 0.0 2.0 0.05
#pragma parameter nes_dither "NES Dither Blend" 1.0 0.0 2.0 0.1
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.2 0.0 20.0 0.05
#pragma parameter chrom_shift "Chroma Horizontal Shift" 0.5 -2.0 2.0 0.1
#pragma parameter tv_mist "TV Signal Mist (Blur)" 0.4 0.0 1.5 0.05
#pragma parameter rb_size "Rainbow Width" 1.2 0.5 30.0 0.1
#pragma parameter rb_tilt "Rainbow Tilt" 1.0 0.0 3.0 0.1

#ifdef GL_ES
precision highp float;
#endif

#if defined(VERTEX)
attribute vec4 VertexCoord; attribute vec2 TexCoord;
varying vec2 vTexCoord; uniform mat4 MVPMatrix;
void main() { gl_Position = MVPMatrix * VertexCoord; vTexCoord = TexCoord; }

#elif defined(FRAGMENT)
uniform sampler2D Texture;
uniform vec2 TextureSize;
varying vec2 vTexCoord;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_art, nes_dither, COL_BLEED, chrom_shift, tv_mist, rb_size, rb_tilt;
#endif

mat3 RGBtoYIQ = mat3(0.2989, 0.5870, 0.1140, 0.5959, -0.2744, -0.3216, 0.2115, -0.5229, 0.3114);
mat3 YIQtoRGB = mat3(1.0, 0.956, 0.6210, 1.0, -0.2720, -0.6474, 1.0, -1.1060, 1.7046);

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 0.0);
    
    // --- 1. TV MIST / BLUR (تطبيق الضبابية) ---
    vec3 c_raw = texture2D(Texture, vTexCoord).rgb;
    // سحب عينة مزاحة لعمل تأثير الضبابية
    vec3 c_blur = texture2D(Texture, vTexCoord + ps * tv_mist).rgb;
    vec3 c = mix(c_raw, c_blur, 0.5);

    // --- 2. LUMA PREP (الإضاءة) ---
    vec3 l_side = texture2D(Texture, vTexCoord - ps * nes_dither).rgb;
    
    // حساب الـ Luma مع دمج تأثير الضبابية
    float luma = (mix(c, (c + l_side) * 0.5, 0.5) * RGBtoYIQ).r;

    // --- 3. CHROMA SHIFT & BLEED (الألوان) ---
    vec2 shift_uv = vTexCoord - (ps * chrom_shift);
    vec3 col_s = texture2D(Texture, shift_uv).rgb;
    
    float bleed_step = ps.x * COL_BLEED;
    vec2 c1 = (texture2D(Texture, shift_uv - vec2(bleed_step, 0.0)).rgb * RGBtoYIQ).gb;
    vec2 c2 = (texture2D(Texture, shift_uv + vec2(bleed_step, 0.0)).rgb * RGBtoYIQ).gb;
    
    vec2 mixed_chroma = ((col_s * RGBtoYIQ).gb + c1 + c2) * 0.333;

    // --- 4. 3-PHASE RAINBOW ---
    float x = vTexCoord.x * TextureSize.x;
    float y = vTexCoord.y * TextureSize.y;
    float angle = (x + y * rb_tilt) * (2.09439 / rb_size);
    
    float diff = luma - (l_side * RGBtoYIQ).r;
    float rainbowI = diff * sin(angle) * ntsc_art;
    float rainbowQ = diff * cos(angle) * ntsc_art;

    // --- التجميع النهائي ---
    vec3 final_yiq = vec3(luma, mixed_chroma.x + rainbowI, mixed_chroma.y + rainbowQ);
    
    gl_FragColor = vec4(clamp(final_yiq * YIQtoRGB, 0.0, 1.0), 1.0);
}
#endif