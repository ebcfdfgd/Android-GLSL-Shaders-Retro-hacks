// --- NTSC MEGA LITE + CHROMA (Universal Zero-Off Logic) ---
// Optimized for Android - Any feature at 0.0 acts as if it's not in the code.
// Logic 1010: Directional Red Persistence Persistence Integrated.

#version 110

#pragma parameter ntsc_res "NTSC: Resolution" 0.0 -1.0 1.0 0.05
#pragma parameter ntsc_sharp "NTSC: Sharpness Boost" 0.1 -1.0 1.0 0.05
#pragma parameter fring "NTSC: Edge Fringing" 0.0 0.0 1.0 0.05
#pragma parameter afacts "NTSC: Artifact Intensity" 0.0 0.0 1.0 0.05
#pragma parameter ntsc_hue "NTSC Color Hue (Cyan Fix)" 0.0 -3.14 3.14 0.05
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.0 0.0 5.0 0.05
#pragma parameter red_persistence "Red Persistence (Right Smear)" 1.0 0.0 2.5 0.05
#pragma parameter rb_power "Rainbow Strength" 0.15 0.0 2.0 0.01
#pragma parameter rb_size "Rainbow Width" 3.0 0.5 10.0 0.1
#pragma parameter rb_detect "Rainbow Detection" 0.30 0.0 1.0 0.01
#pragma parameter rb_speed "Rainbow Crawl Speed (0=OFF)" 0.5 0.0 2.0 0.05
#pragma parameter rb_tilt "Rainbow Diagonal Tilt" 0.5 -2.0 2.0 0.1
#pragma parameter de_dither "MD De-Dither Intensity" 1.0 0.0 2.0 0.1
#pragma parameter ntsc_grain "Signal Grain (RF Noise)" 0.01 0.0 0.20 0.01
#pragma parameter tv_mist "TV Signal Mist (Blur)" 0.1 0.0 1.5 0.05

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
varying vec2 hue_trig; 
uniform mat4 MVPMatrix;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_hue;
#endif

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
    hue_trig = vec2(cos(ntsc_hue), sin(ntsc_hue));
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;
varying vec2 vTexCoord;
varying vec2 hue_trig;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_res, ntsc_sharp, fring, afacts;
uniform float ntsc_hue, COL_BLEED, red_persistence, rb_power, rb_size, rb_detect, rb_speed, rb_tilt, de_dither, ntsc_grain, tv_mist;
#endif

float noise(vec2 co) {
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

mat3 RGBtoYIQ = mat3(0.2989, 0.5870, 0.1140, 0.5959, -0.2744, -0.3216, 0.2115, -0.5229, 0.3114);
mat3 YIQtoRGB = mat3(1.0, 0.956, 0.6210, 1.0, -0.2720, -0.6474, 1.0, -1.1060, 1.7046);

void main() {
    float res_step = 1.0 - (ntsc_res * 0.5);
    vec2 ps = vec2(res_step / TextureSize.x, 1.0 / TextureSize.y);
    float time = float(FrameCount);
    
    // --- 1. SMART FETCHES & DE-DITHER ---
    vec3 col_m = texture2D(Texture, vTexCoord).rgb;
    
    vec3 col_l = (de_dither > 0.0) ? texture2D(Texture, vTexCoord - vec2(ps.x * de_dither, 0.0)).rgb : col_m;
    vec3 col_r = (de_dither > 0.0) ? texture2D(Texture, vTexCoord + vec2(ps.x * de_dither, 0.0)).rgb : col_m;

    vec3 col = (de_dither > 0.0) ? mix(col_m, (col_l + col_r) * 0.5, 0.4) : col_m;
    vec3 yiq = col * RGBtoYIQ;
    float lumaL = (col_l * RGBtoYIQ).r;
    float lumaR = (col_r * RGBtoYIQ).r;

    // --- 2. CHROMA BLEED & PERSISTENCE ---
    vec2 mixed_chroma = yiq.gb;
    if (COL_BLEED > 0.0 || red_persistence > 0.0) {
        float bleed_offset = ps.x * (COL_BLEED + 0.0001) * 2.0;
        vec2 chrL = (texture2D(Texture, vTexCoord - vec2(bleed_offset, 0.0)).rgb * RGBtoYIQ).gb;
        vec2 chrR = (texture2D(Texture, vTexCoord + vec2(bleed_offset, 0.0)).rgb * RGBtoYIQ).gb;
        
        // مزج الكروما العام
        mixed_chroma = mix(yiq.gb, (chrL + chrR) * 0.5, 0.5);

        // إضافة سيلان الأحمر: سحب قيمة I من اليسار إلى اليمين
        if (red_persistence > 0.0) {
            float smear = mix(yiq.g, chrL.x, 0.4 * red_persistence);
            mixed_chroma.x = mix(mixed_chroma.x, smear, 0.6);
        }
    }

    // --- 3. RAINBOW KILL-SWITCH ---
    float rainbowI = 0.0;
    float rainbowQ = 0.0;
    if (rb_speed > 0.0 && rb_power > 0.0) {
        float edge = abs(yiq.r - lumaL) + abs(yiq.r - lumaR);
        float rb_mask = smoothstep(rb_detect, rb_detect + 0.2, edge);
        float angle = (vTexCoord.x * TextureSize.x / rb_size) + (vTexCoord.y * TextureSize.y * rb_tilt) + (time * rb_speed) + ntsc_hue; 
        float total_rb = rb_power + (afacts * 0.5);
        rainbowI = sin(angle) * total_rb * rb_mask;
        rainbowQ = cos(angle) * total_rb * rb_mask;
    }

    // --- 4. LUMA & SHARPNESS ---
    float y = yiq.r;
    if (ntsc_sharp > 0.0) y += (yiq.r - lumaL) * (ntsc_sharp * 0.6);
    
    float final_y = (tv_mist > 0.0) ? mix(y, (lumaL + y + lumaR) * 0.333, tv_mist) : y;
    
    if (ntsc_grain > 0.0) final_y += (noise(vTexCoord + mod(time, 60.0)) - 0.5) * ntsc_grain;

    // --- 5. FRINGING & ASSEMBLY ---
    float fI = mixed_chroma.x + rainbowI;
    float fQ = mixed_chroma.y + rainbowQ;
    
    if (fring > 0.0) {
        fI += (yiq.r - lumaR) * fring * 0.3;
        fQ -= (yiq.r - lumaL) * fring * 0.3;
    }
    
    float hueI = fI * hue_trig.x - fQ * hue_trig.y;
    float hueQ = fI * hue_trig.y + fQ * hue_trig.x;

    vec3 final_rgb = vec3(final_y, hueI, hueQ) * YIQtoRGB;

    gl_FragColor = vec4(clamp(final_rgb, 0.0, 1.0), 1.0);
}
#endif