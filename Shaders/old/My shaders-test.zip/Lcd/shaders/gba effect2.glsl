#version 130

#if defined(VERTEX)
in vec4 VertexCoord;
in vec2 TexCoord;
out vec2 vTexCoord;
uniform mat4 MVPMatrix;
void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

in vec2 vTexCoord;
out vec4 FragColor;

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;

// =========================================================
// 1. إعدادات الحركة (Natural LCD Ghosting)
// =========================================================
#pragma parameter GHOST_STR "LCD Ghosting Intensity" 0.55 0.0 1.0 0.05
#pragma parameter MOTION_OFS "Motion Spread" 0.7 0.0 2.0 0.05
#pragma parameter RESPONSE_LAG "LCD Lag Jitter" 0.4 0.0 1.5 0.05

// =========================================================
// 2. معالجة الصورة (Contrast, Gamma, Saturation)
// =========================================================
#pragma parameter SATURATION "Color Saturation" 1.1 0.0 2.0 0.05
#pragma parameter CONTRAST "Contrast Intensity" 1.15 0.5 2.0 0.05
#pragma parameter GAMMA_IN "Gamma Correction" 1.10 0.5 3.0 0.05
#pragma parameter BRIGHTNESS "Final Brightness" 1.1 0.5 2.0 0.05

// =========================================================
// 3. التنعيم (Edge Softening)
// =========================================================
#pragma parameter EDGE_SOFT "Edge Softening (AA)" 0.3 0.0 1.0 0.05

uniform float GHOST_STR, MOTION_OFS, RESPONSE_LAG;
uniform float SATURATION, BRIGHTNESS, EDGE_SOFT, CONTRAST, GAMMA_IN;

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 1.0 / TextureSize.y);
    vec2 uv = vTexCoord;
    float time = float(FrameCount);

    // [1] الـ Natural Ghosting
    vec3 col = texture(Texture, uv).rgb;
    
    if (GHOST_STR > 0.0) {
        float toggle = (mod(time, 2.0) > 0.5) ? 1.0 : -1.0;
        float off = (MOTION_OFS + (RESPONSE_LAG * toggle)) * 0.7;
        vec3 s1 = texture(Texture, uv + vec2(ps.x * off, ps.y * off)).rgb;
        vec3 s2 = texture(Texture, uv - vec2(ps.x * off, ps.y * off)).rgb;
        col = mix(col, (s1 + s2) * 0.5, GHOST_STR * 0.65);
    }

    // [2] معالجة الألوان الصافية (بدون Profiles)
    
    // تطبيق الجاما
    col = pow(max(col, 0.0), vec3(GAMMA_IN));

    // تطبيق التباين
    col = (col - 0.5) * CONTRAST + 0.5;

    // تطبيق التشبع والسطوع
    float luma = dot(col, vec3(0.2126, 0.7152, 0.0722));
    col = mix(vec3(luma), col, SATURATION) * BRIGHTNESS;

    // [3] التنعيم النهائي
    vec3 cL = texture(Texture, uv - ps * vec2(1.0, 0.0)).rgb;
    vec3 cR = texture(Texture, uv + ps * vec2(1.0, 0.0)).rgb;
    col = mix(col, (cL + cR) * 0.5, EDGE_SOFT * 0.5);

    FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
#endif