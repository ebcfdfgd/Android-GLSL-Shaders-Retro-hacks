#version 130

/*
    NTSC-ULTIMATE (Rainbow Fix - No Persistence)
    - Integrated: Resolution, Sharpness, Fringing, Artifacts
    - Fixed: Separated Artifact calculation from Chroma Bleed.
*/

// --- البارامترات الجديدة المضافة ---
#pragma parameter ntsc_res "Resolution" 0.0 -1.0 1.0 0.05
#pragma parameter ntsc_sharp "Sharpness" 0.1 -1.0 1.0 0.05
#pragma parameter fring "Fringing" 0.0 0.0 1.0 0.05
#pragma parameter afacts "Artifacts" 0.0 0.0 1.0 0.05

// --- البارامترات الأصلية ---
#pragma parameter Tuning_Sharp "Composite Sharp" 0.0 -30.0 1.0 0.05
#pragma parameter Tuning_Bleed "Composite Bleed" 0.5 0.0 1.0 0.05
#pragma parameter Tuning_Artifacts "Composite Artifacts" 0.5 0.0 1.0 0.05
#pragma parameter NTSCLerp "NTSC Artifacts" 1.0 0.0 1.0 1.0
#pragma parameter NTSCArtifactScale "NTSC Artifact Scale" 255.0 0.0 1000.0 5.0
#pragma parameter animate_artifacts "Animate NTSC Artifacts" 1.0 0.0 1.0 1.0
#pragma parameter Crawl_Speed "NTSC Crawl Speed" 0.10 -2.0 2.0 0.01
#pragma parameter NTSC_Tilt "NTSC Texture Tilt" 0.0 -3.14 3.14 0.1

#if defined(VERTEX)
    #if __VERSION__ >= 130
        #define COMPAT_VARYING out
        #define COMPAT_ATTRIBUTE in
    #else
        #define COMPAT_VARYING varying 
        #define COMPAT_ATTRIBUTE attribute 
    #endif
    COMPAT_ATTRIBUTE vec4 VertexCoord;
    COMPAT_ATTRIBUTE vec4 TexCoord;
    COMPAT_VARYING vec4 TEX0;
    uniform mat4 MVPMatrix;
    void main() { gl_Position = MVPMatrix * VertexCoord; TEX0.xy = TexCoord.xy; }

#elif defined(FRAGMENT)
    precision highp float;
    #if __VERSION__ >= 130
        #define COMPAT_VARYING in
        #define COMPAT_TEXTURE texture
        out vec4 FragColor;
    #else
        #define COMPAT_VARYING varying
        #define FragColor gl_FragColor
        #define COMPAT_TEXTURE texture2D
    #endif

    uniform int FrameCount;
    uniform vec2 TextureSize;
    uniform sampler2D Texture;
    uniform sampler2D NTSCArtifactSampler2; 
    COMPAT_VARYING vec4 TEX0;

    #ifdef PARAMETER_UNIFORM
    uniform float ntsc_res, ntsc_sharp, fring, afacts;
    uniform float Tuning_Sharp, Tuning_Bleed, Tuning_Artifacts;
    uniform float NTSCLerp, NTSCArtifactScale, animate_artifacts, Crawl_Speed, NTSC_Tilt;
    #endif

    const mat3 RGB_to_YIQ = mat3(0.299, 0.587, 0.114, 0.5959, -0.2746, -0.3213, 0.2115, -0.5227, 0.3112);
    const mat3 YIQ_to_RGB = mat3(1.0, 0.956, 0.621, 1.0, -0.272, -0.647, 1.0, -1.106, 1.703);

    float Brightness(vec3 InVal) { return dot(InVal, vec3(0.299, 0.587, 0.114)); }

    void main()
    {
        // [1] Geometry & Resolution
        float res_mod = 1.0 - (ntsc_res * 0.5);
        vec2 SourceSize = vec2(TextureSize);
        vec2 invSize = vec2(res_mod / SourceSize.x, 1.0 / SourceSize.y);
        vec2 dx = vec2(invSize.x, 0.0);
        
        // Fetch Raw Image
        vec3 cur_raw = COMPAT_TEXTURE(Texture, TEX0.xy).rgb;
        vec3 Cur_L = COMPAT_TEXTURE(Texture, TEX0.xy - dx).rgb;
        vec3 Cur_R = COMPAT_TEXTURE(Texture, TEX0.xy + dx).rgb;

        // [2] Calculate NTSC Artifacts (Rainbow)
        float time_offset = float(FrameCount) * Crawl_Speed * 0.01; 
        vec2 scanuv = (TEX0.xy * SourceSize / NTSCArtifactScale);
        scanuv.x += time_offset;
        float cosA = cos(NTSC_Tilt); float sinA = sin(NTSC_Tilt);
        scanuv = vec2(scanuv.x * cosA - scanuv.y * sinA, scanuv.x * sinA + scanuv.y * cosA);
        scanuv = fract(scanuv);

        vec4 art_a = COMPAT_TEXTURE(NTSCArtifactSampler2, scanuv);
        vec4 art_b = COMPAT_TEXTURE(NTSCArtifactSampler2, scanuv + vec2(0.0, 1.0/SourceSize.y));
        float lerpfactor = (animate_artifacts > 0.5) ? mod(float(FrameCount), 2.0) : NTSCLerp;
        vec3 NTSCArtifact = mix(art_a.rgb, art_b.rgb, 1.0 - lerpfactor);

        // Apply Artifacts (دمج afacts الجديد)
        float total_artifacts = Tuning_Artifacts + (afacts * 0.5);
        vec3 res = cur_raw + ((Cur_L - cur_raw) + (Cur_R - cur_raw)) * NTSCArtifact * total_artifacts;

        // [3] Apply Chroma Bleed & Fringing
        float total_bleed = Tuning_Bleed + (fring * 0.5);
        vec3 c_m = res * RGB_to_YIQ;
        vec3 c_l = COMPAT_TEXTURE(Texture, TEX0.xy - dx * (2.0 + total_bleed * 3.0)).rgb * RGB_to_YIQ;
        vec3 c_r = COMPAT_TEXTURE(Texture, TEX0.xy + dx * (2.0 + total_bleed * 3.0)).rgb * RGB_to_YIQ;
        
        vec2 spread_chroma = mix(c_m.yz, (c_l.yz + c_r.yz) * 0.5, total_bleed);
        res = vec3(c_m.x, spread_chroma) * YIQ_to_RGB;

        // [4] Sharpness & Fidelity (دمج ntsc_sharp الجديد)
        float bM = Brightness(res);
        float bL = Brightness(Cur_L);
        float bR = Brightness(Cur_R);
        float total_sharp = Tuning_Sharp + (ntsc_sharp * 0.5);
        float sharp = (bM * 2.0 - bL - bR) * total_sharp;
        res = clamp(res + sharp, 0.0, 1.0);

        FragColor = vec4(res, 1.0);
    } 
#endif