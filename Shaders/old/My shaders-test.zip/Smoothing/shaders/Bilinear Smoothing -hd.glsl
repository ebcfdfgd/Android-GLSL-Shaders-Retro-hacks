#version 130
/* 01-WONDER-REMAKE-MARBLE (ULTIMATE)
   - Bilinear Vector Engine (Wonder Style)
   - Marble Polish Feature (Smooth Stone Texture)
   - Modern Sharpening (HD Detail)
   - Cinematic Color Grading (Warmth & Shadow Tint)
   - Dynamic Rim Lighting & Deep Shadows
   - Intelligence Outline Definition
   - Bloom Glow Effect
*/

#pragma parameter B_SMOOTH "Bilinear Smooth" 2.5 0.0 3.0 0.1
#pragma parameter W_POWER "Wonder Power" 10.0 1.0 10.0 0.5
#pragma parameter M_POLISH "Marble Polish" 0.60 0.0 1.0 0.05
#pragma parameter M_SHARP "Modern Sharpen" 0.40 0.0 1.0 0.05
#pragma parameter OUTLINE "Outline Strength" 0.35 0.0 1.0 0.05
#pragma parameter RIM_STR "Rim Light (Halo)" 0.40 0.0 1.0 0.05
#pragma parameter SHADOW_DP "Deep Shadow Depth" 0.55 0.0 1.0 0.05
#pragma parameter C_WARMTH "Cinematic Warmth" 0.05 -0.20 0.20 0.01
#pragma parameter C_TINT "Shadow Tint (Blue-ish)" 0.03 0.0 0.20 0.01
#pragma parameter GLOW_STR "Bloom Glow Power" 0.3 0.0 1.0 0.05

#if defined(VERTEX)
#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#else
#define COMPAT_VARYING varying
#define COMPAT_ATTRIBUTE attribute
#endif
COMPAT_ATTRIBUTE vec4 VertexCoord, TexCoord;
COMPAT_VARYING vec4 TEX0;
uniform mat4 MVPMatrix;
void main() {
    gl_Position = MVPMatrix * VertexCoord;
    TEX0.xy = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif
#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

uniform vec2 TextureSize;
uniform sampler2D Texture;
COMPAT_VARYING vec4 TEX0;

#ifdef PARAMETER_UNIFORM
uniform float B_SMOOTH, W_POWER, M_POLISH, M_SHARP, OUTLINE, RIM_STR, SHADOW_DP, C_WARMTH, C_TINT, GLOW_STR;
#endif

float get_lum(vec3 c) { return dot(c, vec3(0.299, 0.587, 0.114)); }

void main() {
    vec2 pos = TEX0.xy;
    vec2 texel = 1.0 / TextureSize;
    
    // --- [1] محرك الـ Bilinear الأساسي ---
    vec2 f = fract(pos * TextureSize - 0.5);
    vec3 t00 = COMPAT_TEXTURE(Texture, pos + vec2(-0.5, -0.5) * texel).rgb;
    vec3 t10 = COMPAT_TEXTURE(Texture, pos + vec2( 0.5, -0.5) * texel).rgb;
    vec3 t01 = COMPAT_TEXTURE(Texture, pos + vec2(-0.5,  0.5) * texel).rgb;
    vec3 t11 = COMPAT_TEXTURE(Texture, pos + vec2( 0.5,  0.5) * texel).rgb;
    vec3 bilinear = mix(mix(t00, t10, f.x), mix(t01, t11, f.x), f.y);
    
    // --- [2] محرك الـ Wonder Vector ---
    vec3 c = COMPAT_TEXTURE(Texture, pos).rgb;
    float diff = distance(t00, t11) + distance(t10, t01);
    vec3 wonder = mix(c, bilinear, clamp(diff * W_POWER, 0.0, 1.0));
    
    // --- [3] ميزة الرخام الناعم (Marble Polish) ---
    // دمج الألوان بطريقة تلغي التدرجات الخشنة وتجعل السطح أملس كالرخام
    vec3 marble = mix(wonder, bilinear, M_POLISH * 0.8);
    vec3 base = mix(c, marble, B_SMOOTH * 0.5);

    // --- [4] Modern Sharpen ---
    vec3 detail = base - bilinear;
    vec3 sharpened = base + (detail * M_SHARP * 2.5);

    // --- [5] Outline Definition ---
    float edge = clamp(diff * 5.0, 0.0, 1.0);
    vec3 outlined = sharpened * (1.0 - (edge * OUTLINE));

    // --- [6] Dynamic Rim Light ---
    vec3 up = COMPAT_TEXTURE(Texture, pos - vec2(0.0, texel.y)).rgb;
    float rim = max(get_lum(base) - get_lum(up), 0.0);
    vec3 rim_final = outlined + (vec3(rim) * RIM_STR * base * 2.0);

    // --- [7] Deep Shadows ---
    float luma = get_lum(base);
    float shadow_mask = smoothstep(0.45, 0.0, luma);
    vec3 final = mix(rim_final, rim_final * 0.4, shadow_mask * SHADOW_DP);

    // --- [8] Cinematic Color Grading ---
    final.r += C_WARMTH * luma;
    final.b += C_TINT * shadow_mask;
    final.g -= (C_WARMTH * 0.2) * luma;

    // --- [9] Bloom Glow Effect ---
    float glow_mask = smoothstep(0.40, 0.95, luma);
    final += (bilinear * GLOW_STR) * glow_mask;

    FragColor = vec4(clamp(final, 0.0, 1.0), 1.0);
}
#endif