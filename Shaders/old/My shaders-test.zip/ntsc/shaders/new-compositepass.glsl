#version 130

// Parameter lines
#pragma parameter NTSC_Select "NTSC Texture Select: 0:Orig 1:Sec" 0.0 0.0 1.0 1.0
#pragma parameter Tuning_Sharp "Composite Sharp" 0.0 -30.0 1.0 0.05
#pragma parameter Tuning_Persistence_R "Red Persistence" 0.075 0.0 1.0 0.01
#pragma parameter Tuning_Persistence_G "Green Persistence" 0.05 0.0 1.0 0.01
#pragma parameter Tuning_Persistence_B "Blue Persistence" 0.05 0.0 1.0 0.01
#pragma parameter Tuning_Bleed "Composite Bleed" 0.5 0.0 1.0 0.05
#pragma parameter Tuning_Artifacts "Composite Artifacts" 0.5 0.0 1.0 0.05
#pragma parameter NTSCLerp "NTSC Artifacts" 1.0 0.0 1.0 1.0
#pragma parameter NTSCArtifactScale "NTSC Artifact Scale" 255.0 0.0 1000.0 5.0
#pragma parameter animate_artifacts "Animate NTSC Artifacts" 1.0 0.0 1.0 1.0

#define lerp(a, b, c) mix(a, b, c)
#define tex2D(a, b) COMPAT_TEXTURE(a, b)
#define half4 vec4
#define half2 vec2
#define half float
#define saturate(c) clamp(c, 0.0, 1.0)

#if defined(VERTEX)
#if __VERSION__ >= 130
#define COMPAT_VARYING out
#define COMPAT_ATTRIBUTE in
#else
#define COMPAT_VARYING varying 
#define COMPAT_ATTRIBUTE attribute 
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 COLOR;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec4 COL0;
COMPAT_VARYING vec4 TEX0;

uniform mat4 MVPMatrix;

void main()
{
    gl_Position = MVPMatrix * VertexCoord;
    COL0 = COLOR;
    TEX0.xy = TexCoord.xy;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

uniform int FrameCount;
uniform vec2 TextureSize;
uniform vec2 InputSize;
uniform sampler2D Texture;
uniform sampler2D NTSCArtifactSampler;
uniform sampler2D NTSCArtifactSampler2; 
uniform sampler2D PrevTexture;
uniform sampler2D Prev2Texture;
uniform sampler2D Prev4Texture;
COMPAT_VARYING vec4 TEX0;

#define Source Texture
#define vTexCoord TEX0.xy
#define SourceSize vec4(TextureSize, 1.0 / TextureSize)

#ifdef PARAMETER_UNIFORM
uniform float NTSC_Select;
uniform float Tuning_Sharp;
uniform float Tuning_Persistence_R;
uniform float Tuning_Persistence_G;
uniform float Tuning_Persistence_B;
uniform float Tuning_Bleed;
uniform float Tuning_Artifacts;
uniform float NTSCLerp;
uniform float NTSCArtifactScale;
uniform float animate_artifacts;
#endif

float Brightness(vec4 InVal) { return dot(InVal, vec4(0.299, 0.587, 0.114, 0.0)); }

void main()
{
    vec2 fragcoord = (vTexCoord * (SourceSize.xy / InputSize.xy)) * (InputSize.xy / SourceSize.xy);
    vec2 scanuv = vec2(fract(fragcoord * 1.0001 * SourceSize.xy / NTSCArtifactScale));
    
    // الحل الأمثل لمنع الفشل: سحب العينات من الاثنين ثم التبديل بين النتائج
    vec4 art1_a = tex2D(NTSCArtifactSampler, scanuv);
    vec4 art1_b = tex2D(NTSCArtifactSampler, scanuv + vec2(0.0, 1.0 / SourceSize.y));
    
    vec4 art2_a = tex2D(NTSCArtifactSampler2, scanuv);
    vec4 art2_b = tex2D(NTSCArtifactSampler2, scanuv + vec2(0.0, 1.0 / SourceSize.y));

    // التبديل بين النتائج النهائية (أكثر استقراراً برمجياً)
    vec4 NTSCArtifact1 = (NTSC_Select > 0.5) ? art2_a : art1_a;
    vec4 NTSCArtifact2 = (NTSC_Select > 0.5) ? art2_b : art1_b;

    float lerpfactor = (animate_artifacts > 0.5) ? mod(float(FrameCount), 2.0) : NTSCLerp;
    vec4 NTSCArtifact = mix(NTSCArtifact1, NTSCArtifact2, 1.0 - lerpfactor);
    
    vec2 LeftUV = vTexCoord - vec2(1.0 / SourceSize.x, 0.0);
    vec2 RightUV = vTexCoord + vec2(1.0 / SourceSize.x, 0.0);
    
    vec4 Cur_Left = tex2D(Source, LeftUV);
    vec4 Cur_Local = tex2D(Source, vTexCoord);
    vec4 Cur_Right = tex2D(Source, RightUV);
    
    vec4 TunedNTSC = NTSCArtifact * Tuning_Artifacts;
    
    vec4 Prev = (COMPAT_TEXTURE(Prev4Texture, vTexCoord) + COMPAT_TEXTURE(Prev2Texture, vTexCoord) + COMPAT_TEXTURE(PrevTexture, vTexCoord)) * 0.333;
    vec4 Prev_L = (COMPAT_TEXTURE(Prev4Texture, LeftUV) + COMPAT_TEXTURE(Prev2Texture, LeftUV) + COMPAT_TEXTURE(PrevTexture, LeftUV)) * 0.333;
    vec4 Prev_R = (COMPAT_TEXTURE(Prev4Texture, RightUV) + COMPAT_TEXTURE(Prev2Texture, RightUV) + COMPAT_TEXTURE(PrevTexture, RightUV)) * 0.333;
    
    Cur_Local = saturate(Cur_Local + (((Cur_Left - Cur_Local) + (Cur_Right - Cur_Local)) * TunedNTSC));
    
    float curBrt = Brightness(Cur_Local);
    float offset = 0.0;
    float SharpWeight[3] = float[](1.0, -0.3162277, 0.1);
    
    for (int i = 0; i < 3; ++i)
    {
        vec2 StepSize = (vec2(1.0/TextureSize.x, 0.0) * float(i + 1));
        float NBrtL = Brightness(tex2D(Source, vTexCoord - StepSize));
        float NBrtR = Brightness(tex2D(Source, vTexCoord + StepSize));
        offset += (((curBrt - NBrtL) + (curBrt - NBrtR)) * SharpWeight[i]);
    }
    
    Cur_Local = saturate(Cur_Local + (offset * Tuning_Sharp * mix(vec4(1.0), NTSCArtifact, Tuning_Artifacts)));
    vec4 Tuning_Persistence = vec4(Tuning_Persistence_R, Tuning_Persistence_G, Tuning_Persistence_B, 1.0);
    Cur_Local = saturate(max(Cur_Local, Tuning_Persistence * (10.0 / (1.0 + (2.0 * Tuning_Bleed))) * (Prev + ((Prev_L + Prev_R) * Tuning_Bleed))));
    
    FragColor = vec4(Cur_Local);
} 
#endif