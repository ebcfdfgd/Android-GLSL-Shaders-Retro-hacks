// --- Blargg Turbo-Lite (Mobile Speed Optimized) + RF Grain ---
// Optimization: Smart Bypass on Zero Parameters + Added Saturation & Black Level
#version 110

#pragma parameter ntsc_hue "NTSC Phase Shift" 0.0 -3.14 3.14 0.05
#pragma parameter SATURATION "Saturation" 1.0 0.0 2.0 0.05
#pragma parameter BLACK_LEVEL "Black Level" 0.0 -0.5 0.5 0.01
#pragma parameter COL_BLEED "Chroma Bleed Strength" 1.2 0.0 5.0 0.05
#pragma parameter rb_power "Rainbow Transparency (Strength)" 0.35 0.0 2.0 0.01
#pragma parameter dot_crawl "Dot Crawl Intensity" 0.25 0.0 1.0 0.01
#pragma parameter de_dither "Dither Blending Strength" 0.50 0.0 1.0 0.01
#pragma parameter pi_mod "Subcarrier Phase Angle" 131.5 0.0 360.0 0.1
#pragma parameter vert_scal "Vertical Phase Scale" 0.5 0.0 2.0 0.01
#pragma parameter sig_noise "Signal RF Grain" 0.04 0.0 10.2 0.01

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
varying vec2 vHueTrig; 
uniform mat4 MVPMatrix;
uniform float ntsc_hue;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
    vHueTrig = vec2(cos(ntsc_hue), sin(ntsc_hue));
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision mediump float;
#endif

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;
varying vec2 vTexCoord;
varying vec2 vHueTrig;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_hue, SATURATION, BLACK_LEVEL, COL_BLEED, rb_power, dot_crawl, de_dither, pi_mod, vert_scal;
uniform float sig_noise;
#endif

const vec3 kY = vec3(0.299, 0.587, 0.114);
const vec3 kI = vec3(0.596, -0.274, -0.322);
const vec3 kQ = vec3(0.211, -0.523, 0.311);

// RF Grain Hash
float hash(vec2 co) { return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453); }

void main() {
    vec3 cM = texture2D(Texture, vTexCoord).rgb;
    
    // --- Smart Bypass System ---
    // Added Saturation (1.0 default) and Black Level (0.0 default) check to bypass
    if (rb_power <= 0.0 && dot_crawl <= 0.0 && sig_noise <= 0.0 && COL_BLEED <= 0.0 && de_dither <= 0.0 && SATURATION == 1.0 && BLACK_LEVEL == 0.0) {
        gl_FragColor = vec4(cM, 1.0);
        return; 
    }

    vec2 ps = vec2(1.0 / TextureSize.x, 0.0);
    float time = float(FrameCount);
    
    vec3 cL = texture2D(Texture, vTexCoord - ps).rgb;
    vec3 cR = texture2D(Texture, vTexCoord + ps).rgb;

    float yM = dot(cM, kY);
    float yL = dot(cL, kY);
    float yR = dot(cR, kY);

    float auto_detect = clamp(abs(yL - yM) + abs(yR - yM) - abs(yL - yR), 0.0, 1.0);
    float mask = smoothstep(0.02, 0.15, auto_detect);

    float phase = (floor(vTexCoord.x * TextureSize.x) * pi_mod * 0.01745) + 
                  (floor(vTexCoord.y * TextureSize.y) * vert_scal * 3.14159) + 
                  (mod(time, 2.0) * 3.14159);
    
    vec2 s_c = vec2(sin(phase), cos(phase));

    // Luma + Artifacts
    float final_y = mix(yM, (yL + yM + yR) * 0.333, de_dither * mask);
    
    if (dot_crawl > 0.0) final_y += s_c.x * dot_crawl * mask;
    
    if (sig_noise > 0.0)
        final_y += (hash(vTexCoord + time * 0.01) - 0.5) * sig_noise;

    float i = dot(cM, kI);
    float q = dot(cM, kQ);

    if (rb_power > 0.0) {
        i = mix(i, i + s_c.x * mask, rb_power);
        q = mix(q, q + s_c.y * mask, rb_power);
    }

    if (COL_BLEED > 0.0) {
        float iL = dot(cL, kI);
        i = mix(i, iL, 0.2); 
    }

    // Apply Saturation on I and Q channels
    float fI = (i * vHueTrig.x - q * vHueTrig.y) * SATURATION;
    float fQ = (i * vHueTrig.y + q * vHueTrig.x) * SATURATION;

    vec3 rgb = vec3(
        final_y + 0.956 * fI + 0.621 * fQ,
        final_y - 0.272 * fI - 0.647 * fQ,
        final_y - 1.106 * fI + 1.703 * fQ
    );
    
    // Apply Black Level
    rgb = mix(vec3(BLACK_LEVEL), vec3(1.0), rgb);
    
    gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), 1.0);
}
#endif