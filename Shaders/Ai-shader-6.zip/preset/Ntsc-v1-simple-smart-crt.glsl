shaders = "1"
feedback_pass = "0"
shader0 = "shaders/Ntsc-v1-simple-smart-crt.glsl"
scale_type0 = source
scale0 = 1.0




