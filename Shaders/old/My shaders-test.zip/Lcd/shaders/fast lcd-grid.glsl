#version 130
/* ULTIMATE-LCD-ACCURACY (PRINCE - COLOR FIXED)
   - Precise Subpixel Geometry
   - Smart Color Balance (Anti-Green Tint)
   - Optimized for Mali/Adreno 604/754
*/

#pragma parameter GRID_STR "LCD Grid Intensity" 0.5 0.0 1.0 0.05
#pragma parameter SUBPIX_STR "Subpixel Strength" 0.6 0.0 1.0 0.05
#pragma parameter BRIGHTNESS_LCD "LCD Brightness" 1.1 1.0 2.0 0.05

#if defined(VERTEX)
#if __VERSION__ >= 130
#define COMPAT_ATTRIBUTE in
#define COMPAT_VARYING out
#else
#define COMPAT_ATTRIBUTE attribute
#define COMPAT_VARYING varying
#endif

COMPAT_ATTRIBUTE vec4 VertexCoord;
COMPAT_ATTRIBUTE vec4 TexCoord;
COMPAT_VARYING vec2 vTexCoord;
COMPAT_VARYING vec2 pix_coord;

uniform mat4 MVPMatrix;
uniform vec2 TextureSize;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord.xy;
    pix_coord = vTexCoord * TextureSize;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision highp float;
#endif

#if __VERSION__ >= 130
#define COMPAT_VARYING in
#define COMPAT_TEXTURE texture
out vec4 FragColor;
#else
#define COMPAT_VARYING varying
#define FragColor gl_FragColor
#define COMPAT_TEXTURE texture2D
#endif

COMPAT_VARYING vec2 vTexCoord;
COMPAT_VARYING vec2 pix_coord;
uniform sampler2D Texture;

#ifdef PARAMETER_UNIFORM
uniform float GRID_STR, SUBPIX_STR, BRIGHTNESS_LCD;
#else
#define GRID_STR 0.5
#define SUBPIX_STR 0.6
#define BRIGHTNESS_LCD 1.1
#endif

void main() {
    // 1. سحب اللون من الـ Pass السابق (012)
    vec3 color = COMPAT_TEXTURE(Texture, vTexCoord).rgb;

    // 2. حساب المسافة داخل البكسل
    vec2 subpix_pos = fract(pix_coord);
    
    // محاكاة الشبكة السوداء (Grid)
    vec2 grid = smoothstep(0.5 - GRID_STR * 0.5, 0.5 + GRID_STR * 0.5, abs(subpix_pos - 0.5));
    float mask = 1.0 - max(grid.x, grid.y);

    // 3. محاكاة الـ Subpixel مع موازنة الألوان
    float x_offset = subpix_pos.x * 3.0;
    vec3 weights;
    
    weights.r = clamp(1.0 - abs(x_offset - 0.5), 0.0, 1.0);
    weights.g = clamp(1.0 - abs(x_offset - 1.5), 0.0, 1.0) * 0.88;
    weights.b = clamp(1.0 - abs(x_offset - 2.5), 0.0, 1.0) * 1.05;
    
    vec3 subpixel = mix(vec3(1.0), weights * 1.5, SUBPIX_STR);

    // 4. النتيجة النهائية
    color *= mask;
    color *= subpixel;
    color *= BRIGHTNESS_LCD;

    FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
#endif