#version 110

// --- الإعدادات الأصلية والمضافة لـ 8 ---
#pragma parameter ntsc_hue "NTSC Color Hue (Cyan Fix)" 0.0 -3.14 3.14 0.05
#pragma parameter COL_BLEED "Chroma Bleed Strength" 2.0 0.0 20.0 0.05
#pragma parameter rb_power "Rainbow Strength" 0.2 0.0 2.0 0.05
#pragma parameter rb_size "Rainbow Width" 5.0 0.5 10.0 0.1
#pragma parameter rb_slant "Rainbow Tilt/Rotation" 0.0 -2.0 2.0 0.05
#pragma parameter rb_speed "Rainbow Cycle Speed" 0.03 0.0 1.0 0.01
#pragma parameter rb_detect "Rainbow Detection" 0.35 0.0 1.0 0.01
#pragma parameter de_dither "MD De-Dither (Sonic Water)" 0.50 0.0 2.0 0.1
#pragma parameter NOISE_STR "Analog Signal Noise" 0.01 0.0 0.5 0.01
#pragma parameter ghosting "Signal Ghosting (Ringing)" 0.3 0.0 1.0 0.05
#pragma parameter tv_mist "TV Signal Mist (Blur)" 0.4 0.0 1.5 0.05
#pragma parameter JITTER "Signal Jitter (Shake)" 0.02 0.0 5.5 0.01
#pragma parameter MD_SHARP "Luma Sharpness" 0.2 0.0 2.0 0.05

#if defined(VERTEX)
attribute vec4 VertexCoord;
attribute vec2 TexCoord;
varying vec2 vTexCoord;
uniform mat4 MVPMatrix;

void main() {
    gl_Position = MVPMatrix * VertexCoord;
    vTexCoord = TexCoord;
}

#elif defined(FRAGMENT)
#ifdef GL_ES
precision mediump float;
#endif

uniform sampler2D Texture;
uniform vec2 TextureSize;
uniform int FrameCount;
varying vec2 vTexCoord;

#ifdef PARAMETER_UNIFORM
uniform float ntsc_hue, COL_BLEED, rb_power, rb_size, rb_slant, rb_speed, rb_detect;
uniform float de_dither, NOISE_STR, ghosting, tv_mist, JITTER, MD_SHARP;
#endif

float rand(vec2 co){ return fract(sin(dot(co.xy ,vec2(12.98, 78.23))) * 437.5); }

void main() {
    vec2 ps = vec2(1.0 / TextureSize.x, 1.0 / TextureSize.y);
    float time = float(FrameCount);

    // --- 0. JITTER (تطبيق الاهتزاز) ---
    vec2 uv = vTexCoord;
    uv.x += (rand(vec2(time, uv.y)) - 0.5) * JITTER * ps.x;

    float bleed = ps.x * COL_BLEED;

    // --- 1. SIGNAL GHOSTING & DE-DITHER ---
    vec3 main_col = texture2D(Texture, uv).rgb;
    vec3 ghost_col = texture2D(Texture, uv - vec2(ps.x * 2.0, 0.0)).rgb;
    vec3 c_left = texture2D(Texture, uv - vec2(ps.x * de_dither, 0.0)).rgb;
    vec3 c_right = texture2D(Texture, uv + vec2(ps.x * de_dither, 0.0)).rgb;
    
    vec3 col = mix(main_col, ghost_col, ghosting * 0.4);
    col = (col * 0.5) + (c_left * 0.25) + (c_right * 0.25);

    // --- 2. التحويل اليدوي لـ YIQ ---
    #define RGB_TO_YIQ(c) vec3(dot(c, vec3(0.2989, 0.5870, 0.1140)), dot(c, vec3(0.5959, -0.2744, -0.3216)), dot(c, vec3(0.2115, -0.5229, 0.3114)))

    vec3 res    = RGB_TO_YIQ(col);
    vec3 resr   = RGB_TO_YIQ(texture2D(Texture, uv - vec2(2.0*bleed, 0.0)).rgb);
    vec3 resru  = RGB_TO_YIQ(texture2D(Texture, uv - vec2(ps.x, 0.0)).rgb);
    vec3 resl   = RGB_TO_YIQ(texture2D(Texture, uv + vec2(2.0*bleed, 0.0)).rgb);
    vec3 reslu  = RGB_TO_YIQ(texture2D(Texture, uv + vec2(bleed, 0.0)).rgb);

    // --- 3. CHROMA MIXING (الحفاظ على طريقة 8) ---
    vec2 mixed_chroma = (res.gb + resr.gb + resl.gb + reslu.gb) / 4.0;

    // --- 4. RAINBOW (مع التدوير والسرعة) ---
    float lC = res.r;
    float lL = resru.r;
    float lR = dot(texture2D(Texture, uv + vec2(ps.x, 0.0)).rgb, vec3(0.2989, 0.5870, 0.1140));
    float diff = abs(lC - lL) + abs(lC - lR);
    float rb_mask = smoothstep(rb_detect, rb_detect + 0.1, diff);

    // إضافة الإمالة (uv.y * rb_slant) والسرعة (time * rb_speed)
    float angle = (uv.x * TextureSize.x / rb_size) + (uv.y * TextureSize.y * rb_slant) + (time * rb_speed);
    float rainbowI = sin(angle) * rb_power * rb_mask;
    float rainbowQ = cos(angle) * rb_power * rb_mask;

    // --- 5. MIST, SHARPNESS & NOISE ---
    float final_y = mix(res.r, (lL + lC + lR) / 3.0, tv_mist);
    final_y += (lC - lL) * MD_SHARP; // إضافة الحدة
    if(NOISE_STR > 0.0) final_y += (rand(uv + time * 0.01) - 0.5) * NOISE_STR;

    // --- 6. HUE SHIFT & ASSEMBLY ---
    float cosA = cos(ntsc_hue);
    float sinA = sin(ntsc_hue);
    
    float fI = mixed_chroma.x + rainbowI;
    float fQ = mixed_chroma.y + rainbowQ;
    
    float hueI = fI * cosA - fQ * sinA;
    float hueQ = fI * sinA + fQ * cosA;

    vec3 final_rgb;
    final_rgb.r = final_y + 0.9563 * hueI + 0.6210 * hueQ;
    final_rgb.g = final_y - 0.2721 * hueI - 0.6474 * hueQ;
    final_rgb.b = final_y - 1.1070 * hueI + 1.7046 * hueQ;

    gl_FragColor = vec4(clamp(final_rgb, 0.0, 1.0), 1.0);
}
#endif